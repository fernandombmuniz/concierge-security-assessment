//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-Ci_UJ8g1.js
var manifest = {
	"9ca52ce4aa10b3440afc94c3046896e5a7f57e15d698cb475e4f862a07a6ab74": {
		functionName: "listInternalAssessments_createServerFn_handler",
		importer: () => import("./_ssr/internal.functions-CJBtjQJY.mjs")
	},
	"d41e6b99bc0389cbedfde2a2806fdb442b5c1613d9a71de862845630da2a7a90": {
		functionName: "getInternalAssessment_createServerFn_handler",
		importer: () => import("./_ssr/internal.functions-CJBtjQJY.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
