//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DXHZO1DL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/assessment",
			"/auth",
			"/concluido",
			"/diagnostico",
			"/resultado"
		],
		preloads: [
			"/assets/index-v2LuA1Ne.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/useRouter-P4PaR9MS.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-v2LuA1Ne.js"
		} }]
	},
	"/": {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CioC7qXF.js",
			"/assets/router-compat-QkrA-YOn.js",
			"/assets/monitor-smartphone-B1zNNjhj.js",
			"/assets/key-round-lJWnzHCV.js",
			"/assets/assessment-session-B69hUVqd.js",
			"/assets/loader-circle-Bvs_Hg5s.js",
			"/assets/shield-check-DkWjlpba.js",
			"/assets/wifi-D2xHmu7Q.js",
			"/assets/ClientHeader-DJIkCWJS.js"
		]
	},
	"/_authenticated": {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/interno/$id", "/_authenticated/interno/"],
		preloads: ["/assets/route-Ypz8PzO3.js"]
	},
	"/auth": {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BUX7vpEV.js",
			"/assets/key-round-lJWnzHCV.js",
			"/assets/loader-circle-Bvs_Hg5s.js",
			"/assets/shield-check-DkWjlpba.js"
		]
	},
	"/diagnostico": {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/diagnostico.tsx",
		children: void 0,
		preloads: [
			"/assets/diagnostico-Dd3rRidI.js",
			"/assets/router-compat-QkrA-YOn.js",
			"/assets/monitor-smartphone-B1zNNjhj.js",
			"/assets/key-round-lJWnzHCV.js",
			"/assets/building-2-Ds_x0OFx.js",
			"/assets/assessment-session-B69hUVqd.js",
			"/assets/circle-check-C4DrWwsT.js",
			"/assets/info-CgWqmjk0.js",
			"/assets/loader-circle-Bvs_Hg5s.js",
			"/assets/wifi-D2xHmu7Q.js",
			"/assets/ClientHeader-DJIkCWJS.js"
		]
	},
	"/resultado": {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/resultado.tsx",
		children: void 0,
		preloads: [
			"/assets/resultado-wSZUYT8v.js",
			"/assets/router-compat-QkrA-YOn.js",
			"/assets/typeof-B5XbjTb1.js",
			"/assets/monitor-smartphone-B1zNNjhj.js",
			"/assets/triangle-alert-CwBquK4O.js",
			"/assets/key-round-lJWnzHCV.js",
			"/assets/createLucideIcon-ox8sh6X5.js",
			"/assets/circle-check-C4DrWwsT.js",
			"/assets/info-CgWqmjk0.js",
			"/assets/loader-circle-Bvs_Hg5s.js",
			"/assets/shield-check-DkWjlpba.js",
			"/assets/ClientHeader-DJIkCWJS.js"
		]
	},
	"/_authenticated/interno/$id": {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/_authenticated/interno.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/interno._id-3D3oF6uI.js",
			"/assets/internal.functions-rB9CrHyU.js",
			"/assets/router-compat-QkrA-YOn.js",
			"/assets/monitor-smartphone-B1zNNjhj.js",
			"/assets/triangle-alert-CwBquK4O.js",
			"/assets/key-round-lJWnzHCV.js",
			"/assets/createLucideIcon-ox8sh6X5.js",
			"/assets/building-2-Ds_x0OFx.js",
			"/assets/info-CgWqmjk0.js",
			"/assets/shield-check-DkWjlpba.js",
			"/assets/wifi-D2xHmu7Q.js"
		]
	},
	"/_authenticated/interno/": {
		filePath: "D:/Concierge/concierge-security-assessment-v4/concierge-security-assessment/src/routes/_authenticated/interno.index.tsx",
		children: void 0,
		preloads: [
			"/assets/interno.index-DfnmwszM.js",
			"/assets/internal.functions-rB9CrHyU.js",
			"/assets/router-compat-QkrA-YOn.js",
			"/assets/createLucideIcon-ox8sh6X5.js",
			"/assets/loader-circle-Bvs_Hg5s.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
