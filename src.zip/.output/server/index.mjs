globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/assessment-session-B69hUVqd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f441-K7TEtcJkhjdjEgprGO7Klq36BQw\"",
		"mtime": "2026-09-01T19:48:11.766Z",
		"size": 62529,
		"path": "../public/assets/assessment-session-B69hUVqd.js"
	},
	"/assets/auth-BUX7vpEV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dfa-dn5odaiD2ok+lj20/mCQ9Yq7xRg\"",
		"mtime": "2026-09-01T19:48:11.766Z",
		"size": 7674,
		"path": "../public/assets/auth-BUX7vpEV.js"
	},
	"/assets/building-2-Ds_x0OFx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ef-JRCHdAEkYK1+wTPfo219vkU8ljg\"",
		"mtime": "2026-09-01T19:48:11.767Z",
		"size": 495,
		"path": "../public/assets/building-2-Ds_x0OFx.js"
	},
	"/assets/ClientHeader-DJIkCWJS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1739-uiMRr7HMCTh/19c8DW8wE45SbeE\"",
		"mtime": "2026-09-01T19:48:11.766Z",
		"size": 5945,
		"path": "../public/assets/ClientHeader-DJIkCWJS.js"
	},
	"/assets/circle-check-C4DrWwsT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-HpKoThcL5q5CkEl5LTTBowpXmHU\"",
		"mtime": "2026-09-01T19:48:11.770Z",
		"size": 178,
		"path": "../public/assets/circle-check-C4DrWwsT.js"
	},
	"/assets/createLucideIcon-ox8sh6X5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d5-hLdXRHvQZZu34lPzcL9BKYSn57o\"",
		"mtime": "2026-09-01T19:48:11.771Z",
		"size": 1237,
		"path": "../public/assets/createLucideIcon-ox8sh6X5.js"
	},
	"/assets/diagnostico-Dd3rRidI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a42-oZ3Pi0YqiZzTG/m85laChE5bBoE\"",
		"mtime": "2026-09-01T19:48:11.771Z",
		"size": 35394,
		"path": "../public/assets/diagnostico-Dd3rRidI.js"
	},
	"/assets/html2canvas-ydWbLPCJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30b46-IP/zQEbfXqt4Hk0jNBNNzCpjikQ\"",
		"mtime": "2026-09-01T19:48:11.771Z",
		"size": 199494,
		"path": "../public/assets/html2canvas-ydWbLPCJ.js"
	},
	"/assets/index.es-BnroMYBe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24f83-vnKSXULGtHDg+qU8/IJp9xkvDKo\"",
		"mtime": "2026-09-01T19:48:11.772Z",
		"size": 151427,
		"path": "../public/assets/index.es-BnroMYBe.js"
	},
	"/assets/info-CgWqmjk0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cc-9ZlDCJQyySsiaVKFlSTkyvz2iO0\"",
		"mtime": "2026-09-01T19:48:11.772Z",
		"size": 204,
		"path": "../public/assets/info-CgWqmjk0.js"
	},
	"/assets/internal.functions-rB9CrHyU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31bc-5L6+YH37C8mJvRAuUZAmhfYZMHM\"",
		"mtime": "2026-09-01T19:48:11.773Z",
		"size": 12732,
		"path": "../public/assets/internal.functions-rB9CrHyU.js"
	},
	"/assets/interno.index-DfnmwszM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1077-ysDSbNZlqkNFoSRXq6CxRCKSm2o\"",
		"mtime": "2026-09-01T19:48:11.773Z",
		"size": 4215,
		"path": "../public/assets/interno.index-DfnmwszM.js"
	},
	"/assets/interno._id-3D3oF6uI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"501d-DMMNdfI7BWY4LBiIQYza9F76+Jg\"",
		"mtime": "2026-09-01T19:48:11.773Z",
		"size": 20509,
		"path": "../public/assets/interno._id-3D3oF6uI.js"
	},
	"/assets/key-round-lJWnzHCV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"197-oufp3CUDR0Q+zPtFOd2YmZhiszA\"",
		"mtime": "2026-09-01T19:48:11.773Z",
		"size": 407,
		"path": "../public/assets/key-round-lJWnzHCV.js"
	},
	"/assets/loader-circle-Bvs_Hg5s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-w2BPOhhez04EfFGI9Ma7j7MNZL0\"",
		"mtime": "2026-09-01T19:48:11.774Z",
		"size": 144,
		"path": "../public/assets/loader-circle-Bvs_Hg5s.js"
	},
	"/assets/logo-concierge-CwdLN5d7.jpg": {
		"type": "image/jpeg",
		"etag": "\"e745-3W7Zan5RYVRit5t6RVQ1X3Jyb9Q\"",
		"mtime": "2026-09-01T19:48:11.776Z",
		"size": 59205,
		"path": "../public/assets/logo-concierge-CwdLN5d7.jpg"
	},
	"/assets/monitor-smartphone-B1zNNjhj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4849-wZh17r/OtlZGX03GjNGDMc8jsNg\"",
		"mtime": "2026-09-01T19:48:11.774Z",
		"size": 18505,
		"path": "../public/assets/monitor-smartphone-B1zNNjhj.js"
	},
	"/assets/purify.es-BVMDmQta.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68ba-eN4IIuogHYJkQf/Tocsd/Egdkvc\"",
		"mtime": "2026-09-01T19:48:11.774Z",
		"size": 26810,
		"path": "../public/assets/purify.es-BVMDmQta.js"
	},
	"/assets/route-Ypz8PzO3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b-FK0LKVbsKSwwrsTZQr+sfuUcKtM\"",
		"mtime": "2026-09-01T19:48:11.775Z",
		"size": 139,
		"path": "../public/assets/route-Ypz8PzO3.js"
	},
	"/assets/rolldown-runtime-CbXtAM7H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24d-+aXgvbJ1Wwcp2A8AXKIBByksYC8\"",
		"mtime": "2026-09-01T19:48:11.774Z",
		"size": 589,
		"path": "../public/assets/rolldown-runtime-CbXtAM7H.js"
	},
	"/assets/router-compat-QkrA-YOn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"35a-mrFtWlhodGrweC86iXO+Zseyv/4\"",
		"mtime": "2026-09-01T19:48:11.775Z",
		"size": 858,
		"path": "../public/assets/router-compat-QkrA-YOn.js"
	},
	"/assets/index-v2LuA1Ne.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"87f03-p1eNiIM/hNEda6Eq6wf51Z5GrhE\"",
		"mtime": "2026-09-01T19:48:11.765Z",
		"size": 556803,
		"path": "../public/assets/index-v2LuA1Ne.js"
	},
	"/assets/resultado-wSZUYT8v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad18c-CeGpDESGJvorwk1wehdPP4bjJoI\"",
		"mtime": "2026-09-01T19:48:11.774Z",
		"size": 709004,
		"path": "../public/assets/resultado-wSZUYT8v.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-08-30T15:10:46.840Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/routes-CioC7qXF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18f2-RbFM1p8C30inLmNIosYPCEnSTq4\"",
		"mtime": "2026-09-01T19:48:11.775Z",
		"size": 6386,
		"path": "../public/assets/routes-CioC7qXF.js"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"53de-SB+/E4oLbUsSkNKZBmLemimaymk\"",
		"mtime": "2026-08-30T15:10:46.840Z",
		"size": 21470,
		"path": "../public/favicon.png"
	},
	"/assets/typeof-B5XbjTb1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10f-yPXEOGyFHb1Ws7OoWyWNEEBz4mQ\"",
		"mtime": "2026-09-01T19:48:11.776Z",
		"size": 271,
		"path": "../public/assets/typeof-B5XbjTb1.js"
	},
	"/assets/triangle-alert-CwBquK4O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1329-jTyzjycmaT1ETtO9EwkjTqVp77g\"",
		"mtime": "2026-09-01T19:48:11.775Z",
		"size": 4905,
		"path": "../public/assets/triangle-alert-CwBquK4O.js"
	},
	"/assets/styles-DJ7FiOFq.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"19bd5-a9MnPYwJeKi4Us11JKt4KTB9Wts\"",
		"mtime": "2026-09-01T19:48:11.776Z",
		"size": 105429,
		"path": "../public/assets/styles-DJ7FiOFq.css"
	},
	"/assets/shield-check-DkWjlpba.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-I7xTGUNVYczfeCTEJBWgg0Mhwtc\"",
		"mtime": "2026-09-01T19:48:11.775Z",
		"size": 320,
		"path": "../public/assets/shield-check-DkWjlpba.js"
	},
	"/assets/useRouter-P4PaR9MS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f38-JeuRZo+y+piGPymlEbWpp6OPhZo\"",
		"mtime": "2026-09-01T19:48:11.776Z",
		"size": 7992,
		"path": "../public/assets/useRouter-P4PaR9MS.js"
	},
	"/assets/wifi-D2xHmu7Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"118-VTFjQteIqYD/lB7KAnz4OBXpX0A\"",
		"mtime": "2026-09-01T19:48:11.776Z",
		"size": 280,
		"path": "../public/assets/wifi-D2xHmu7Q.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_JQj6V6 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_JQj6V6
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
