import { i as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as CircleQuestionMark, b as ChevronDown, c as MonitorSmartphone, d as KeyRound, f as Info, h as Database, i as TrendingUp, m as Download, o as ShieldCheck, r as TriangleAlert, s as Server, t as X, u as LoaderCircle, v as CircleCheck, y as ChevronRight } from "../_libs/lucide-react.mjs";
import { a as useSearchParams, r as useNavigate$1 } from "./router-compat-D1jUaSai.mjs";
import { r as scoreAssessment } from "./scoring-CLIBbsft.mjs";
import { i as loadDraft, r as getSubmission, t as ClientHeader } from "./ClientHeader-DBh3ZhLU.mjs";
import { n as ImpactChart, r as ScoreGauge, t as DomainBars } from "./ImpactChart-DY4KBzpy.mjs";
import { t as html2canvas } from "../_libs/html2canvas-pro.mjs";
import { t as E } from "../_libs/jspdf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resultado-DlPxfS4f.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SOURCES = [
	{
		id: "nist-csf-2",
		organization: "NIST",
		reportTitle: "Cybersecurity Framework (CSF) 2.0",
		year: "2024",
		statement: "O CSF 2.0 organiza resultados de cibersegurança em Governar, Identificar, Proteger, Detectar, Responder e Recuperar, apoiando a priorização e a comunicação de riscos.",
		sourceUrl: "https://www.nist.gov/cyberframework",
		validated: true,
		domains: [
			"Rede e Perímetro",
			"Endpoints",
			"Backup e Continuidade",
			"Identidade e Acesso"
		]
	},
	{
		id: "cis-network-infrastructure",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 12 · Network Infrastructure Management",
		year: "v8.1",
		statement: "O CIS recomenda manter e gerenciar ativamente os dispositivos de rede, incluindo atualização, configuração segura e revisão da infraestrutura.",
		sourceUrl: "https://www.cisecurity.org/controls/network-infrastructure-management",
		validated: true,
		domains: ["Rede e Perímetro"],
		findingKeywords: [
			"perímetro",
			"firewall",
			"infraestrutura de rede",
			"manutenção"
		]
	},
	{
		id: "cis-audit-logs",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 8 · Audit Log Management",
		year: "v8.1",
		statement: "O CIS recomenda coletar, revisar, alertar e reter logs que possam ajudar a detectar, compreender ou recuperar-se de um incidente.",
		sourceUrl: "https://www.cisecurity.org/controls/audit-log-management",
		validated: true,
		domains: ["Rede e Perímetro"],
		findingKeywords: [
			"acompanhamento",
			"reativo",
			"monitoramento",
			"alertas"
		]
	},
	{
		id: "cis-network-monitoring",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 13 · Network Monitoring and Defense",
		year: "v8.1",
		statement: "O CIS trata monitoramento e defesa de rede como uma capacidade contínua para ampliar visibilidade e resposta diante de ameaças.",
		sourceUrl: "https://www.cisecurity.org/controls/cis-controls-list",
		validated: true,
		domains: ["Rede e Perímetro"],
		findingKeywords: [
			"prevenção ativa",
			"ameaças",
			"inspeção"
		]
	},
	{
		id: "cis-malware-defense",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 10 · Malware Defenses",
		year: "v8.1",
		statement: "O CIS recomenda controles para prevenir ou controlar a instalação, execução e propagação de códigos maliciosos nos ativos da organização.",
		sourceUrl: "https://www.cisecurity.org/controls/cis-controls-list",
		validated: true,
		domains: ["Endpoints"],
		findingKeywords: [
			"detectar comportamentos",
			"computadores",
			"endpoint",
			"proteção atual"
		]
	},
	{
		id: "cis-vulnerability-management",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 7 · Continuous Vulnerability Management",
		year: "v8.1",
		statement: "O CIS recomenda manter um processo para identificar, priorizar e corrigir vulnerabilidades nos ativos da organização.",
		sourceUrl: "https://www.cisecurity.org/controls/cis-controls-list",
		validated: true,
		domains: ["Endpoints"],
		findingKeywords: ["vulnerabilidade"]
	},
	{
		id: "cis-asset-inventory",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 1 · Inventory and Control of Enterprise Assets",
		year: "v8.1",
		statement: "O CIS recomenda manter conhecimento atualizado dos ativos conectados ao ambiente para apoiar proteção, atualização e responsabilização.",
		sourceUrl: "https://www.cisecurity.org/controls/cis-controls-list",
		validated: true,
		domains: ["Endpoints"],
		findingKeywords: [
			"ativos",
			"inventário",
			"visibilidade"
		]
	},
	{
		id: "cis-access-control",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 6 · Access Control Management",
		year: "v8.1",
		statement: "O CIS recomenda criar, atribuir, gerenciar e revogar credenciais e privilégios, além de reforçar autenticação para acessos relevantes.",
		sourceUrl: "https://www.cisecurity.org/controls/access-control-management",
		validated: true,
		domains: ["Endpoints", "Identidade e Acesso"],
		findingKeywords: [
			"privilégios",
			"administrador",
			"mfa",
			"senha",
			"compartilhadas",
			"acesso"
		]
	},
	{
		id: "cis-data-recovery",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 11 · Data Recovery",
		year: "v8.1",
		statement: "O CIS recomenda práticas de recuperação capazes de restaurar ativos a um estado confiável, incluindo backup automatizado, proteção das cópias e testes de recuperação.",
		sourceUrl: "https://www.cisecurity.org/controls/data-recovery",
		validated: true,
		domains: ["Backup e Continuidade"],
		findingKeywords: [
			"recuperação",
			"backup",
			"cópias",
			"restauração"
		]
	},
	{
		id: "cis-email-browser",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 9 · Email and Web Browser Protections",
		year: "v8.1",
		statement: "O CIS recomenda ampliar a proteção de e-mail e navegação para reduzir a exposição a conteúdo malicioso e técnicas de engenharia social.",
		sourceUrl: "https://www.cisecurity.org/controls/cis-controls-list",
		validated: true,
		domains: ["Identidade e Acesso"],
		findingKeywords: ["e-mail", "phishing"]
	},
	{
		id: "cis-incident-response",
		organization: "Center for Internet Security",
		reportTitle: "CIS Control 17 · Incident Response Management",
		year: "v8.1",
		statement: "O CIS recomenda definir capacidade de resposta a incidentes com responsáveis, procedimentos, comunicação e critérios de escalonamento.",
		sourceUrl: "https://www.cisecurity.org/controls/cis-controls-list",
		validated: true,
		domains: ["Identidade e Acesso"],
		findingKeywords: ["incidente", "resposta"]
	},
	{
		id: "anpd-first-fine",
		organization: "ANPD",
		reportTitle: "Primeira multa por descumprimento à LGPD",
		year: "2023",
		statement: "Em 2023, a ANPD aplicou duas multas simples à microempresa Telekall Infoservice, totalizando R$ 14.400, além de advertência. O caso é específico e não representa estimativa de sanção para outras empresas.",
		sourceUrl: "https://www.gov.br/anpd/pt-br/assuntos/noticias/anpd-aplica-a-primeira-multa-por-descumprimento-a-lgpd",
		validated: true
	},
	{
		id: "anpd-small-business",
		organization: "ANPD",
		reportTitle: "Regulamento para agentes de tratamento de pequeno porte",
		year: "2022",
		statement: "A ANPD prevê tratamento regulatório diferenciado para agentes de pequeno porte, mas esclarece que as flexibilizações não afastam o cumprimento dos demais dispositivos da LGPD.",
		sourceUrl: "https://www.gov.br/anpd/pt-br/acesso-a-informacao/institucional/atos-normativos/regulamentacoes_anpd/resolucao-cd-anpd-no-2-de-27-de-janeiro-de-2022",
		validated: true
	}
];
function getValidatedSource(id) {
	const entry = SOURCES.find((source) => source.id === id);
	return entry?.validated ? entry : null;
}
function getValidatedSourceForDomain(domain) {
	return SOURCES.find((source) => source.validated && source.domains?.includes(domain)) ?? null;
}
function getValidatedSourceForFinding(title, domain) {
	const normalizedTitle = title.toLowerCase();
	return SOURCES.find((source) => source.validated && source.domains?.includes(domain) && source.findingKeywords?.some((keyword) => normalizedTitle.includes(keyword.toLowerCase()))) ?? getValidatedSourceForDomain(domain);
}
var PDF_BACKGROUND = "#020617";
var CAPTURE_WIDTH_PX = 1440;
var SLIDE_WIDTH_MM = 338.67;
var SLIDE_HEIGHT_MM = 190.5;
var SLIDE_PADDING_MM = 8;
var nextFrame = () => new Promise((resolve) => {
	requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
});
var waitForImages = async (root) => {
	const images = Array.from(root.querySelectorAll("img"));
	await Promise.all(images.map(async (image) => {
		if (image.complete) return;
		await new Promise((resolve) => {
			const done = () => resolve();
			image.addEventListener("load", done, { once: true });
			image.addEventListener("error", done, { once: true });
		});
	}));
};
var removeInteractiveElements = (root) => {
	root.querySelectorAll("[data-pdf-ignore=\"true\"]").forEach((element) => element.remove());
};
var prepareClone = (source) => {
	const clone = source.cloneNode(true);
	clone.removeAttribute("data-assessment-report");
	clone.style.width = `${CAPTURE_WIDTH_PX}px`;
	clone.style.maxWidth = `${CAPTURE_WIDTH_PX}px`;
	clone.style.minWidth = `${CAPTURE_WIDTH_PX}px`;
	clone.style.margin = "0";
	clone.style.padding = "34px";
	clone.style.boxSizing = "border-box";
	clone.style.background = PDF_BACKGROUND;
	removeInteractiveElements(clone);
	const host = document.createElement("div");
	host.setAttribute("aria-hidden", "true");
	host.style.position = "fixed";
	host.style.left = "-20000px";
	host.style.top = "0";
	host.style.width = `${CAPTURE_WIDTH_PX}px`;
	host.style.zIndex = "-9999";
	host.style.background = PDF_BACKGROUND;
	host.style.pointerEvents = "none";
	host.style.overflow = "hidden";
	host.appendChild(clone);
	document.body.appendChild(host);
	return {
		host,
		clone
	};
};
var collectUsefulBreaks = (root) => {
	const rootRect = root.getBoundingClientRect();
	return Array.from(root.querySelectorAll("section, article, [data-report-slide-break=\"true\"]")).map((element) => {
		const rect = element.getBoundingClientRect();
		return {
			top: Math.max(0, rect.top - rootRect.top),
			height: rect.height
		};
	}).filter((item) => item.top > 0 && item.height > 0).map((item) => item.top).sort((a, b) => a - b);
};
var collectTopLevelSectionStarts = (root) => {
	const rootRect = root.getBoundingClientRect();
	return Array.from(root.children).filter((element) => element instanceof HTMLElement).filter((element) => element.tagName.toLowerCase() === "section").map((element) => {
		const rect = element.getBoundingClientRect();
		return Math.max(0, rect.top - rootRect.top);
	}).filter((top) => top > 0).sort((a, b) => a - b);
};
var collectProtectedRanges = (root) => {
	const rootRect = root.getBoundingClientRect();
	return Array.from(root.querySelectorAll("article")).map((element) => {
		const rect = element.getBoundingClientRect();
		return {
			start: Math.max(0, rect.top - rootRect.top),
			end: Math.max(0, rect.bottom - rootRect.top)
		};
	}).filter((range) => range.end > range.start).sort((a, b) => a.start - b.start);
};
var buildSlideSlices = (totalHeight, targetHeight, breaks, protectedRanges = []) => {
	const slides = [];
	let start = 0;
	while (start < totalHeight - 1) {
		let idealEnd = Math.min(totalHeight, start + targetHeight);
		if (idealEnd >= totalHeight) {
			slides.push({
				start,
				end: totalHeight
			});
			break;
		}
		const crossingRange = protectedRanges.find((range) => range.start < idealEnd && range.end > idealEnd && range.end > start);
		if (crossingRange) {
			const contentBeforeCard = crossingRange.start - start;
			const fullCardHeight = crossingRange.end - crossingRange.start;
			if (contentBeforeCard >= targetHeight * .34) idealEnd = crossingRange.start;
			else idealEnd = Math.min(totalHeight, Math.max(crossingRange.end, start + Math.min(fullCardHeight, targetHeight)));
		} else {
			const minUseful = start + targetHeight * .64;
			const candidate = breaks.filter((point) => point > minUseful && point < idealEnd).at(-1);
			if (candidate && candidate > start + 250) idealEnd = candidate;
		}
		if (idealEnd <= start + 1) idealEnd = Math.min(totalHeight, start + targetHeight);
		slides.push({
			start,
			end: idealEnd
		});
		start = idealEnd;
	}
	return slides;
};
var cropCanvas = (source, startY, endY) => {
	const height = Math.max(1, endY - startY);
	const slice = document.createElement("canvas");
	slice.width = source.width;
	slice.height = height;
	const context = slice.getContext("2d");
	if (!context) throw new Error("Não foi possível preparar o slide do relatório.");
	context.fillStyle = PDF_BACKGROUND;
	context.fillRect(0, 0, slice.width, slice.height);
	context.drawImage(source, 0, startY, source.width, height, 0, 0, source.width, height);
	return slice;
};
var fitInsideSlide = (imageWidth, imageHeight) => {
	const availableWidth = 322.67;
	const availableHeight = 174.5;
	const imageRatio = imageWidth / imageHeight;
	if (imageRatio >= availableWidth / availableHeight) {
		const width = availableWidth;
		const height = width / imageRatio;
		return {
			width,
			height,
			x: SLIDE_PADDING_MM,
			y: (SLIDE_HEIGHT_MM - height) / 2
		};
	}
	const height = availableHeight;
	const width = height * imageRatio;
	return {
		width,
		height,
		x: (SLIDE_WIDTH_MM - width) / 2,
		y: SLIDE_PADDING_MM
	};
};
var sanitizePdfFileName = (value) => {
	return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase() || "empresa";
};
async function generateAssessmentPdf(source, options) {
	const generatedAt = options.generatedAt ?? /* @__PURE__ */ new Date();
	const { host, clone } = prepareClone(source);
	try {
		await nextFrame();
		await waitForImages(clone);
		const capture = await html2canvas(clone, {
			backgroundColor: PDF_BACKGROUND,
			scale: 1.5,
			useCORS: true,
			allowTaint: false,
			logging: false,
			width: CAPTURE_WIDTH_PX,
			windowWidth: 1440,
			scrollX: 0,
			scrollY: 0
		});
		const pdf = new E({
			orientation: "landscape",
			unit: "mm",
			format: [SLIDE_WIDTH_MM, SLIDE_HEIGHT_MM],
			compress: true
		});
		pdf.setProperties({
			title: `Concierge Security Assessment - ${options.companyName || "Relatório"}`,
			subject: "Relatório executivo de segurança",
			author: "Concierge Segurança Digital",
			creator: "Concierge Security Assessment"
		});
		const targetSlideHeightCss = clone.scrollWidth * (174.5 / 322.67);
		const breaks = collectUsefulBreaks(clone);
		const topLevelSections = collectTopLevelSectionStarts(clone);
		const protectedRanges = collectProtectedRanges(clone);
		const firstSlideEnd = topLevelSections.length >= 3 ? topLevelSections[2] : Math.min(clone.scrollHeight, targetSlideHeightCss);
		const remainingBreaks = breaks.filter((point) => point > firstSlideEnd);
		const remainingSlices = firstSlideEnd < clone.scrollHeight ? buildSlideSlices(clone.scrollHeight - firstSlideEnd, targetSlideHeightCss, remainingBreaks.map((point) => point - firstSlideEnd), protectedRanges.filter((range) => range.end > firstSlideEnd).map((range) => ({
			start: Math.max(0, range.start - firstSlideEnd),
			end: Math.max(0, range.end - firstSlideEnd)
		}))).map(({ start, end }) => ({
			start: start + firstSlideEnd,
			end: end + firstSlideEnd
		})) : [];
		const slicesCss = [{
			start: 0,
			end: firstSlideEnd
		}, ...remainingSlices];
		const scaleY = capture.height / clone.scrollHeight;
		const slides = slicesCss.map(({ start, end }) => ({
			start: Math.max(0, Math.round(start * scaleY)),
			end: Math.min(capture.height, Math.round(end * scaleY))
		}));
		const totalSlides = slides.length;
		slides.forEach(({ start, end }, index) => {
			if (index > 0) pdf.addPage([SLIDE_WIDTH_MM, SLIDE_HEIGHT_MM], "landscape");
			pdf.setFillColor(2, 6, 23);
			pdf.rect(0, 0, SLIDE_WIDTH_MM, SLIDE_HEIGHT_MM, "F");
			const slideCanvas = cropCanvas(capture, start, end);
			const image = slideCanvas.toDataURL("image/jpeg", .95);
			const placement = fitInsideSlide(slideCanvas.width, slideCanvas.height);
			pdf.addImage(image, "JPEG", placement.x, placement.y, placement.width, placement.height, void 0, "FAST");
			pdf.setFont("helvetica", "normal");
			pdf.setFontSize(7.2);
			pdf.setTextColor(100, 116, 139);
			pdf.text(`Concierge Security Assessment${options.companyName ? ` | ${options.companyName}` : ""}`, 8, 186);
			pdf.text(`${index + 1} / ${totalSlides}`, 330.67, 186, { align: "right" });
		});
		const dateLabel = new Intl.DateTimeFormat("pt-BR", {
			dateStyle: "medium",
			timeStyle: "short"
		}).format(generatedAt);
		pdf.setPage(totalSlides);
		pdf.setFontSize(6.4);
		pdf.setTextColor(71, 85, 105);
		pdf.text(`Gerado em ${dateLabel}. Diagnóstico inicial baseado nas informações fornecidas durante o Assessment.`, 8, 188.7);
		pdf.save(options.fileName);
	} finally {
		host.remove();
	}
}
var plainDomainLabel = (domain) => {
	if (domain === "Rede e Perímetro") return "Internet e rede";
	if (domain === "Endpoints") return "Computadores";
	if (domain === "Backup e Continuidade") return "Dados e backup";
	if (domain === "Identidade e Acesso") return "Contas e acessos";
	return domain;
};
var networkSituationText = (data) => {
	switch (data.firewallLevel) {
		case "none": return "Você informou que a empresa não possui uma solução dedicada para proteger a conexão com a internet.";
		case "isp": return "Você informou que a empresa utiliza principalmente o equipamento fornecido pela operadora para proteger a conexão com a internet.";
		case "router": return "Você informou que a empresa utiliza MikroTik ou outro roteador corporativo para proteger a conexão com a internet.";
		case "utm": return "Você informou que a empresa possui um equipamento próprio para proteger a conexão com a internet.";
		case "ngfw": return "Você informou que a empresa possui uma solução de segurança com recursos adicionais de proteção da internet.";
		case "managed_ngfw": return "Você informou que a empresa possui uma solução de segurança acompanhada por equipe especializada.";
		default: return "Pelas respostas, existe alguma proteção entre a internet e a rede da empresa, mas parte das informações ainda precisa ser confirmada.";
	}
};
var getFindingPresentation = (title, data, originalSituation, originalConsequence) => {
	const t = title.toLowerCase();
	if (t.includes("perímetro") || t.includes("firewall")) return {
		title: "A proteção da internet pode ser ampliada",
		informed: networkSituationText(data),
		indication: "Existe uma camada de proteção, mas vale confirmar se ela também consegue identificar e bloquear ameaças além das regras básicas de acesso.",
		practical: "Na prática, uma proteção mais completa pode reduzir a dependência de perceber um problema somente depois que ele já afetou pessoas ou sistemas."
	};
	if (t.includes("reativo") || t.includes("acompanhamento")) return {
		title: "Os alertas são acompanhados principalmente quando surge um problema",
		informed: data.monitoring === "reactive_it" ? "Você informou que a equipe de TI verifica alertas quando existe alguma necessidade ou sintoma." : originalSituation,
		indication: "Isso indica que o acompanhamento tende a acontecer depois de algum sinal percebido pela operação.",
		practical: "Alguns eventos podem ser percebidos apenas quando começam a afetar pessoas, sistemas ou a internet da empresa."
	};
	if (t.includes("antivírus") || t.includes("detectar") || t.includes("computadores")) return {
		title: "Os computadores possuem proteção, mas pode faltar visibilidade quando algo escapa do antivírus",
		informed: data.endpointLevel === "business_av" ? "Você informou que os computadores utilizam antivírus corporativo." : originalSituation,
		indication: "O antivírus é uma primeira camada importante. Pelas respostas, vale confirmar se existe capacidade adicional para entender o que aconteceu quando uma ameaça consegue passar por essa proteção.",
		practical: "Pode levar mais tempo para descobrir quais computadores foram afetados e quais ações precisam ser tomadas."
	};
	if (t.includes("vulnerabilidade") || t.includes("atualiza")) return {
		title: "Atualizações e correções de segurança merecem uma rotina mais previsível",
		informed: originalSituation,
		indication: "As respostas indicam que a identificação de equipamentos ou sistemas desatualizados pode depender de verificações ocasionais ou reativas.",
		practical: "Uma rotina definida ajuda a reduzir o tempo em que computadores e sistemas permanecem expostos a falhas já conhecidas."
	};
	if (t.includes("inventário") || t.includes("ativos")) return {
		title: "Vale melhorar a visão sobre quais equipamentos fazem parte do ambiente",
		informed: originalSituation,
		indication: "Ter uma relação atualizada dos equipamentos ajuda a confirmar se todos estão protegidos e atualizados.",
		practical: "Sem essa visão, algum computador pode ficar fora das rotinas de proteção ou manutenção sem que isso seja percebido."
	};
	if (t.includes("recuperação") || t.includes("backup") || t.includes("cópias")) return {
		title: "A recuperação dos dados ainda pode depender de processos pouco previsíveis",
		informed: data.backupLevel === "manual" ? "Você informou que as cópias de segurança dependem de execução manual." : originalSituation,
		indication: "Existe uma forma de recuperar informações, mas vale confirmar se as cópias são automáticas, protegidas e disponíveis quando realmente forem necessárias.",
		practical: "Em uma perda de dados ou parada, a retomada pode depender da disponibilidade de pessoas e de etapas manuais."
	};
	if (t.includes("testada") || t.includes("restauração")) return {
		title: "A empresa ainda precisa confirmar se consegue recuperar os dados na prática",
		informed: "Você informou que a restauração das cópias ainda não foi testada.",
		indication: "Ter uma cópia é importante, mas um teste é o que confirma se os dados podem ser recuperados como esperado.",
		practical: "Sem um teste anterior, eventuais dificuldades podem aparecer somente no momento em que a recuperação for necessária."
	};
	if (t.includes("senha") || t.includes("mfa")) return {
		title: "Algumas contas podem depender apenas da senha",
		informed: "Você informou que nem todas as contas importantes utilizam uma confirmação adicional além da senha.",
		indication: "Uma segunda confirmação ajuda a proteger o acesso mesmo quando uma senha é descoberta ou reutilizada indevidamente.",
		practical: "Isso reduz a chance de uma senha vazada ser suficiente para acessar uma conta importante."
	};
	if (t.includes("compartilhadas")) return {
		title: "Contas compartilhadas podem dificultar o controle de acessos",
		informed: "Você informou que existem contas utilizadas por mais de uma pessoa.",
		indication: "Quando cada pessoa possui sua própria conta, fica mais fácil controlar permissões e remover acessos individualmente.",
		practical: "Também fica mais simples identificar quem realizou uma determinada ação."
	};
	if (t.includes("e-mail") || t.includes("phishing")) return {
		title: "O e-mail pode depender principalmente dos filtros básicos",
		informed: originalSituation,
		indication: "Vale confirmar se existe proteção adicional para identificar mensagens falsas, links perigosos e anexos suspeitos.",
		practical: "Isso ajuda a reduzir a dependência de o próprio usuário perceber sozinho uma tentativa de golpe."
	};
	if (t.includes("incidente") || t.includes("resposta")) return {
		title: "Vale definir previamente quem coordena a resposta a um problema de segurança",
		informed: "Você informou que não existe um responsável claramente definido para coordenar esse tipo de situação.",
		indication: "Saber quem deve ser acionado evita que essa decisão precise ser tomada durante o próprio incidente.",
		practical: "Isso pode tornar os primeiros passos mais rápidos e organizados quando cada minuto importa."
	};
	return {
		title,
		informed: originalSituation,
		indication: originalConsequence,
		practical: getOperationalImpact(title)
	};
};
var rangeLabel = (n, kind = "people") => {
	const noun = kind === "people" ? "pessoas" : "equipamentos";
	if (!n) return `Não informado`;
	if (n <= 10) return `Até 10 ${noun}`;
	if (n <= 20) return `11 a 20 ${noun}`;
	if (n <= 50) return `21 a 50 ${noun}`;
	if (n <= 100) return `51 a 100 ${noun}`;
	if (n <= 200) return `101 a 200 ${noun}`;
	return `Mais de 200 ${noun}`;
};
var money = (n) => new Intl.NumberFormat("pt-BR", {
	style: "currency",
	currency: "BRL",
	maximumFractionDigits: 0
}).format(n);
var getOperationalImpact = (title) => {
	const t = title.toLowerCase();
	if (t.includes("perímetro") || t.includes("firewall")) return "Na prática, uma proteção mais simples pode perceber menos tipos de ameaça antes que elas alcancem os computadores e sistemas da empresa.";
	if (t.includes("licenciamento")) return "Alguns recursos de segurança podem deixar de receber atualizações ou inteligência recente, reduzindo a cobertura esperada da solução.";
	if (t.includes("reativo") || t.includes("acompanhamento")) return "Quando o acompanhamento é principalmente reativo, alguns eventos podem ser percebidos somente depois de gerar sintomas para pessoas, sistemas ou para a operação.";
	if (t.includes("capacidade de detectar") || t.includes("computadores")) return "A equipe pode depender mais de sinais visíveis ou investigação manual para perceber comportamentos suspeitos nos computadores.";
	if (t.includes("atualizações") || t.includes("vulnerabilidade")) return "O principal efeito é ampliar o intervalo entre a disponibilidade de uma correção e sua aplicação nos ativos que realmente precisam dela.";
	if (t.includes("privilégios") || t.includes("administrador")) return "Privilégios elevados ampliam o que uma conta ou aplicação consegue alterar no equipamento, por isso normalmente exigem controle mais próximo.";
	if (t.includes("recuperação") || t.includes("backup") || t.includes("cópias")) return "Em uma necessidade real de recuperação, a retomada pode depender mais de ações manuais ou de cópias que compartilham o mesmo contexto do ambiente principal.";
	if (t.includes("testada") || t.includes("restauração")) return "Sem um teste anterior, a empresa só confirma tempo, integridade e procedimento de recuperação quando realmente precisa restaurar os dados.";
	if (t.includes("senha") || t.includes("mfa")) return "Sem uma segunda etapa de confirmação, a proteção do acesso depende mais diretamente da segurança da senha utilizada.";
	if (t.includes("compartilhadas")) return "O principal efeito é reduzir a rastreabilidade: fica mais difícil saber quem realizou uma ação e remover o acesso de uma pessoa específica.";
	if (t.includes("incidente") || t.includes("resposta")) return "Em uma ocorrência relevante, responsáveis, contatos e próximos passos podem precisar ser definidos durante o próprio incidente.";
	if (t.includes("e-mail") || t.includes("phishing")) return "Mensagens suspeitas podem depender mais dos filtros básicos e da percepção do usuário, especialmente em tentativas de phishing e fraude.";
	return "Esse ponto merece uma revisão para confirmar se a empresa consegue perceber o problema rapidamente e agir quando necessário.";
};
function ClientResults() {
	const [searchParams] = useSearchParams();
	const navigate = useNavigate$1();
	const showSuccess = searchParams.get("success") === "true";
	const urlId = searchParams.get("id");
	const [assessmentData, setAssessmentData] = (0, import_react.useState)(() => {
		if (urlId) {
			const sub = getSubmission(urlId);
			if (sub) return sub.data;
		}
		const lastId = localStorage.getItem("concierge-client-last-assessment-id-v2");
		if (lastId) {
			const sub = getSubmission(lastId);
			if (sub) return sub.data;
		}
		return loadDraft();
	});
	const [isFromSubmission, setIsFromSubmission] = (0, import_react.useState)(() => {
		if (urlId) return !!getSubmission(urlId);
		const lastId = localStorage.getItem("concierge-client-last-assessment-id-v2");
		return !!lastId && !!getSubmission(lastId);
	});
	const [isScoreModalOpen, setIsScoreModalOpen] = (0, import_react.useState)(false);
	const [isDiagnosisModalOpen, setIsDiagnosisModalOpen] = (0, import_react.useState)(false);
	const [isFaixaModalOpen, setIsFaixaModalOpen] = (0, import_react.useState)(false);
	const [expandedFindings, setExpandedFindings] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const [isPdfGenerating, setIsPdfGenerating] = (0, import_react.useState)(false);
	const [pdfMode, setPdfMode] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (urlId) {
			const sub = getSubmission(urlId);
			if (sub) {
				setAssessmentData(sub.data);
				setIsFromSubmission(true);
				return;
			}
		}
		const lastId = localStorage.getItem("concierge-client-last-assessment-id-v2");
		if (lastId) {
			const sub = getSubmission(lastId);
			if (sub) {
				setAssessmentData(sub.data);
				setIsFromSubmission(true);
				return;
			}
		}
		setAssessmentData(loadDraft());
		setIsFromSubmission(false);
	}, [urlId]);
	(0, import_react.useEffect)(() => {
		const onKeyDown = (event) => {
			if (event.key !== "Escape") return;
			setIsScoreModalOpen(false);
			setIsDiagnosisModalOpen(false);
			setIsFaixaModalOpen(false);
		};
		window.addEventListener("keydown", onKeyDown);
		return () => window.removeEventListener("keydown", onKeyDown);
	}, []);
	const toggleFinding = (key) => {
		setExpandedFindings((current) => {
			const next = new Set(current);
			if (next.has(key)) next.delete(key);
			else next.add(key);
			return next;
		});
	};
	const handleDownloadReport = async () => {
		if (isPdfGenerating) return;
		setIsPdfGenerating(true);
		setPdfMode(true);
		try {
			await new Promise((resolve) => window.setTimeout(resolve, 160));
			const reportRoot = document.querySelector("[data-assessment-report=\"true\"]");
			if (!reportRoot) throw new Error("Área do relatório não encontrada.");
			const companyName = assessmentData.companyName?.trim() || "empresa";
			await generateAssessmentPdf(reportRoot, {
				companyName,
				fileName: `concierge-security-assessment-${sanitizePdfFileName(companyName)}.pdf`
			});
		} catch (error) {
			console.error("Falha ao gerar PDF do assessment:", error);
			alert("Não foi possível gerar o PDF neste momento. Tente novamente em alguns instantes.");
		} finally {
			setPdfMode(false);
			setIsPdfGenerating(false);
		}
	};
	const draftData = assessmentData;
	if (!!!(draftData.companyName || draftData.contactName || draftData.contactEmail || draftData.users && draftData.users > 0 || draftData.devices && draftData.devices > 0 || draftData.firewallLevel !== "unknown" || draftData.endpointLevel !== "unknown" || draftData.backupLevel !== "unknown" || draftData.mfa !== "unknown")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-dashboard-animate bg-grid-tech px-4 py-7 md:py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card mt-6 p-8 text-center md:p-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "mx-auto text-amber-400 mb-4",
						size: 48
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-bold text-white",
						children: "Nenhum diagnóstico foi realizado ainda"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-400 max-w-lg mx-auto",
						children: "Para visualizar o relatório de postura executiva, acesse a aba do diagnóstico e preencha as informações sobre a sua infraestrutura."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => navigate("/diagnostico"),
						className: "mt-6 inline-flex items-center gap-2 rounded-xl bg-teal-600 px-6 py-3 font-semibold text-white transition hover:bg-teal-500",
						children: "Iniciar diagnóstico"
					})
				]
			})]
		})
	});
	const r = scoreAssessment(draftData);
	const domains = [
		{
			label: "Internet e rede",
			value: r.scores.network,
			coverage: r.domainCoverage.network,
			confidence: r.domainConfidence.network,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, {
				size: 17,
				className: "text-cyan-400"
			})
		},
		{
			label: "Computadores",
			value: r.scores.endpoint,
			coverage: r.domainCoverage.endpoint,
			confidence: r.domainConfidence.endpoint,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonitorSmartphone, {
				size: 17,
				className: "text-cyan-400"
			})
		},
		{
			label: "Dados e backup",
			value: r.scores.backup,
			coverage: r.domainCoverage.backup,
			confidence: r.domainConfidence.backup,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, {
				size: 17,
				className: "text-cyan-400"
			})
		},
		{
			label: "Contas e acessos",
			value: r.scores.identity,
			coverage: r.domainCoverage.identity,
			confidence: r.domainConfidence.identity,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
				size: 17,
				className: "text-cyan-400"
			})
		}
	];
	const affectedDomains = Array.from(new Set(r.findings.map((f) => f.domain)));
	if (affectedDomains.length > 0) {
		const domainLabels = affectedDomains.map((d) => {
			if (d === "Backup e Continuidade") return "recuperação dos dados e cópias de segurança";
			if (d === "Endpoints") return "proteção dos computadores";
			if (d === "Rede e Perímetro") return "proteção da internet e da rede";
			if (d === "Identidade e Acesso") return "proteção das contas e acessos";
			return d.toLowerCase();
		});
		if (domainLabels.length === 1) `${domainLabels[0]}`;
		else if (domainLabels.length === 2) `${domainLabels[0]}${domainLabels[1]}`;
		else {
			const last = domainLabels.pop();
			`${domainLabels.join(", ")}${last}`;
		}
	}
	const priorityExecName = {
		network: "Proteção da internet e da rede",
		endpoint: "Proteção dos computadores",
		backup: "Recuperação dos dados",
		identity: "Proteção das contas e acessos"
	};
	const priorityReasonText = {
		network: "Pelas respostas, este é o ponto que mais merece uma revisão inicial. Vale confirmar se a proteção atual consegue bloquear ameaças, registrar eventos importantes e permitir acompanhamento quando algo acontece.",
		endpoint: "Pelas respostas, vale revisar se a proteção dos computadores vai além do antivírus e se alguém consegue entender e responder quando uma ameaça é detectada.",
		backup: "Pelas respostas, vale confirmar se as cópias são automáticas, protegidas e realmente conseguem recuperar os dados no tempo que a empresa precisa.",
		identity: "Pelas respostas, vale revisar como as contas importantes são protegidas, como os acessos são removidos e quem acompanha situações suspeitas."
	};
	const nextStepText = {
		network: "Revisar como a conexão com a internet é protegida e quem acompanha os alertas",
		endpoint: "Confirmar se a proteção dos computadores permite investigar e responder a ameaças",
		backup: "Testar a recuperação e revisar como as cópias de segurança estão protegidas",
		identity: "Revisar a proteção das contas e a remoção de acessos"
	};
	const priorityFinding = r.findings.find((f) => f.domain === r.priorityLabel) || r.findings[0];
	const validatedPrioritySource = priorityFinding ? getValidatedSourceForDomain(priorityFinding.domain) : null;
	const anpdFineSource = getValidatedSource("anpd-first-fine");
	const anpdSmallBusinessSource = getValidatedSource("anpd-small-business");
	draftData.companyName?.trim();
	const executiveNarrative = r.priority && priorityFinding ? `Com base no que você informou, ${priorityExecName[r.priority].toLowerCase()} foi o ponto que mais chamou atenção neste diagnóstico. ${priorityReasonText[r.priority]} As conclusões abaixo mostram quais respostas levaram a essa leitura e o que vale confirmar primeiro.` : `Com base nas respostas fornecidas, organizamos os principais pontos que vale confirmar ou revisar. O resultado é uma leitura inicial e não substitui uma validação técnica do ambiente.`;
	const evaluatedScoresList = Object.entries(r.scores).filter(([, val]) => val !== null).map(([key, val]) => ({
		key,
		label: r.labels[key],
		score: val
	})).sort((a, b) => a.score - b.score);
	const immediatePriority = evaluatedScoresList[0];
	const nextOpportunity = evaluatedScoresList.length > 1 ? evaluatedScoresList[1] : null;
	const mostMature = evaluatedScoresList.length > 0 ? evaluatedScoresList[evaluatedScoresList.length - 1] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-dashboard-animate bg-grid-tech px-4 py-7 md:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl",
				"data-assessment-report": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientHeader, {}),
					showSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 flex items-start gap-3.5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-5 text-sm text-emerald-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
							className: "text-emerald-400 shrink-0 mt-0.5",
							size: 20
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-slate-100 font-semibold block text-base",
							children: "Diagnóstico enviado com sucesso!"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-slate-300 leading-relaxed",
							children: "As informações foram salvas com sucesso. Veja abaixo o seu relatório de maturidade executiva."
						})] })]
					}),
					!isFromSubmission && !showSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 flex items-start gap-3.5 rounded-2xl border border-amber-500/20 bg-amber-500/5 p-5 text-sm text-amber-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
							className: "text-amber-400 shrink-0 mt-0.5",
							size: 20
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-slate-100 font-semibold block text-base",
							children: "Pré-visualização do diagnóstico"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-slate-400 leading-relaxed",
							children: [
								"Você está visualizando um rascunho com as respostas preenchidas. Para gerar o relatório oficial e persistir os dados, clique em ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-amber-300",
									children: "Enviar assessment"
								}),
								" na última etapa do diagnóstico."
							]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "glass-card p-6 md:p-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-6 md:flex-row md:items-center md:justify-between",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "section-kicker",
									children: "Ambiente Analisado"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 text-2xl font-bold text-white",
									children: "Resumo do diagnóstico"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-slate-400",
									children: "A leitura abaixo foi construída a partir das respostas fornecidas sobre internet, computadores, dados, backup e contas."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex flex-wrap gap-2 text-sm text-slate-300",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-1.5 flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, {
													size: 15,
													className: "text-teal-400"
												}),
												"Indicador geral: ",
												r.level
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-1.5",
											children: ["Setor: ", (draftData.sector === "Outros" ? draftData.sectorOther : draftData.sector) || "Não informado"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-1.5",
											children: rangeLabel(draftData.users, "people")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-1.5",
											children: rangeLabel(draftData.endpointCount || draftData.devices, "devices")
										}),
										draftData.servers > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-1.5",
											children: [draftData.servers, " servidores"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-1.5",
											children: [draftData.sites || 1, " unidades"]
										})
									]
								})
							] })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6 grid gap-6 md:grid-cols-[1fr_1.3fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-6 flex flex-col items-center justify-center text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-bold uppercase tracking-[.16em] text-slate-500 mb-4",
									children: "Indicador de maturidade"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreGauge, {
									value: r.overall,
									size: 160
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xl font-bold text-white",
										children: r.level
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-slate-400 max-w-[240px]",
										children: "O resultado representa a maturidade dos controles informados. Quando algum ponto importante ainda não pôde ser confirmado, ele é sinalizado para validação antes de uma conclusão mais detalhada."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setIsScoreModalOpen(true),
									className: "mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-teal-400 hover:text-teal-300 transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { size: 16 }), "Como calculamos este indicador?"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-6 flex flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "section-kicker",
									children: "Visão Geral"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 text-xl font-bold text-white",
									children: "Visão por área"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-400 mt-1 mb-6",
									children: "Veja como cada área se comportou a partir das respostas fornecidas."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-grow flex flex-col justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainBars, { items: domains })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "glass-card mt-6 p-6 md:p-7",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-5 md:flex-row md:items-start md:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-3xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "section-kicker",
										children: "O que entendemos"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-1 text-xl font-bold text-white",
										children: "O que mais chamou atenção"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-7 text-slate-300",
										children: executiveNarrative
									}),
									validatedPrioritySource && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 text-xs leading-relaxed text-slate-500",
										children: [
											"Referência complementar validada: ",
											validatedPrioritySource.organization,
											", ",
											validatedPrioritySource.reportTitle,
											" (",
											validatedPrioritySource.year,
											")."
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setIsDiagnosisModalOpen(true),
								className: "inline-flex shrink-0 items-center gap-1.5 text-sm font-semibold text-teal-400 hover:text-teal-300 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { size: 16 }), " Como chegamos a esta conclusão?"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-3 border-t border-slate-800/70 pt-5 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xs font-bold uppercase tracking-wider text-slate-500",
									children: "Indicador geral"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-bold text-slate-100",
									children: r.overall !== null ? `${Math.round(r.overall)}/100 · ${r.level}` : "Dados insuficientes"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xs font-bold uppercase tracking-wider text-slate-500",
									children: "Primeiro ponto a revisar"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-bold text-amber-300",
									children: r.priority ? priorityExecName[r.priority] : "Aguardando dados"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xs font-bold uppercase tracking-wider text-slate-500",
									children: "Próximo passo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 font-bold text-slate-100",
									children: r.priority ? nextStepText[r.priority] : "Validar os pontos prioritários identificados"
								})] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "glass-card mt-6 p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "section-kicker",
								children: "Resumo dos pontos principais"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 text-xl font-bold text-white",
									children: "O que vale revisar"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setIsDiagnosisModalOpen(true),
									className: "inline-flex items-center gap-1.5 text-sm font-semibold text-teal-400 hover:text-teal-300 transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { size: 16 }), " Como chegamos a estes pontos?"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-center gap-3.5 rounded-xl border border-slate-800 bg-slate-950/20 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-amber-500/10 border border-amber-500/20",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
										className: "text-amber-300",
										size: 24
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-base font-bold text-slate-200",
									children: [Math.min(r.findings.length, 3), " pontos principais para revisar"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-slate-400 mt-1",
									children: "Selecionamos os pontos que mais ajudam a entender onde vale começar. O restante continua considerado pela metodologia, mas não precisa aparecer todo de uma vez para você."
								})] })]
							})
						]
					}),
					r.priority && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "glass-card mt-6 p-6 border-l-4 border-l-amber-500/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-amber-400",
								children: "Por onde começar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 text-2xl font-bold text-white",
								children: priorityExecName[r.priority]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-slate-300",
								children: priorityReasonText[r.priority]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 inline-flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-950/40 px-3.5 py-1.5 text-xs text-slate-400 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Indicador desta área:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-amber-300 font-bold",
									children: [
										priorityExecName[r.priority],
										" · ",
										r.scores[r.priority],
										"/100"
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "section-kicker",
									children: "Pontos principais"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-2xl font-bold text-white",
									children: "Os principais pontos para revisar"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 max-w-2xl text-sm leading-relaxed text-slate-400",
									children: "Mostramos abaixo até três pontos que mais influenciaram o resultado. Cada um começa pela resposta fornecida e explica o que ela pode representar na prática."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-slate-500",
								children: [Math.min(r.findings.length, 3), " ponto(s) principal(is)"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4",
							children: r.findings.slice(0, 3).map((f, index) => {
								const findingKey = `${plainDomainLabel(f.domain)}-${f.title}-${index}`;
								const isExpanded = pdfMode || expandedFindings.has(findingKey);
								const source = getValidatedSourceForFinding(f.title, f.domain);
								const severityLabel = f.severity === "Alta" ? "Vale revisar primeiro" : f.severity === "Média" ? "Vale revisar" : "Acompanhar";
								const presentation = getFindingPresentation(f.title, draftData, f.situation, f.consequence);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "glass-card overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											if (!pdfMode) toggleFinding(findingKey);
										},
										"aria-expanded": isExpanded,
										className: "w-full p-5 text-left md:p-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-wrap items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
																size: 15,
																className: "text-amber-400"
															}), plainDomainLabel(f.domain)]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `rounded-full px-2.5 py-0.5 text-2xs font-semibold ${f.severity === "Alta" ? "border border-amber-700/25 bg-amber-950/25 text-amber-300" : f.severity === "Média" ? "border border-cyan-800/20 bg-cyan-950/20 text-cyan-300" : "border border-slate-700/30 bg-slate-900/30 text-slate-300"}`,
															children: severityLabel
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "mt-3 text-lg font-bold leading-snug text-slate-100",
														children: presentation.title
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "mt-3 max-w-3xl space-y-3 text-sm leading-relaxed",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "text-slate-300",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
																		className: "text-slate-100",
																		children: "O que você nos informou:"
																	}),
																	" ",
																	presentation.informed
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "text-slate-300",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
																		className: "text-slate-100",
																		children: "O que isso indica:"
																	}),
																	" ",
																	presentation.indication
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "text-slate-400",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
																		className: "text-slate-300",
																		children: "Na prática:"
																	}),
																	" ",
																	presentation.practical
																]
															})
														]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 shrink-0 text-teal-400",
												"aria-hidden": "true",
												children: isExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { size: 20 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 20 })
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-4 flex items-center gap-1.5 text-xs font-semibold text-teal-400",
											children: isExpanded ? "Ocultar detalhes técnicos" : "Ver detalhes técnicos"
										})]
									}), isExpanded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-t border-slate-800/70 px-5 pb-6 pt-5 md:px-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-4 md:grid-cols-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-xl border border-slate-800 bg-slate-950/25 p-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xs font-bold uppercase tracking-wider text-slate-500",
													children: "Detalhe técnico"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-2 text-sm leading-relaxed text-slate-300",
													children: f.technical
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-xl border border-slate-800 bg-slate-950/25 p-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xs font-bold uppercase tracking-wider text-slate-500",
													children: "Referência técnica"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-2 text-sm leading-relaxed text-slate-300",
													children: f.consequence
												})]
											})]
										}), source && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 rounded-xl border border-teal-900/15 bg-teal-950/5 p-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-semibold text-teal-400",
													children: "Referência do controle"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-sm leading-relaxed text-slate-300",
													children: source.statement
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: source.sourceUrl,
													target: "_blank",
													rel: "noreferrer",
													className: "mt-2 inline-flex text-xs font-semibold text-teal-400 transition hover:text-teal-300",
													children: [
														source.organization,
														" · ",
														source.reportTitle,
														" (",
														source.year,
														")"
													]
												})
											]
										})]
									})]
								}, findingKey);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-8 grid gap-6 md:grid-cols-[1fr_1.2fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-6 flex flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "section-kicker",
									children: "Cenário operacional ilustrativo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 text-xl font-bold text-white",
									children: "Quanto uma parada pode representar para a operação"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs leading-relaxed text-slate-400",
									children: "Simulação de ordem de grandeza baseada nas informações fornecidas e em premissas referenciais internas para pequenas e médias empresas."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 rounded-xl border border-cyan-900/15 bg-cyan-950/5 p-3 text-xs leading-relaxed text-slate-300",
									children: "Esta faixa ajuda a dimensionar uma conversa de negócio. Ela não representa previsão de perda, multa ou orçamento de recuperação."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 text-3xl font-extrabold text-white",
									children: [
										money(r.impactRange[0]),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-base font-normal text-slate-500",
											children: "a"
										}),
										" ",
										money(r.impactRange[1])
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setIsFaixaModalOpen(true),
								className: "mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-teal-400 hover:text-teal-300 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { size: 16 }), "Como estimamos essa faixa?"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-6 flex flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "section-kicker",
									children: "Composição da faixa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 text-xl font-bold text-white",
									children: "De onde vem a estimativa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-400 mt-1 mb-4",
									children: "Componentes usados para transformar uma indisponibilidade em uma referência operacional compreensível."
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-grow flex flex-col justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImpactChart, { components: r.impactComponents })
							})]
						})]
					}),
					draftData.sensitiveData === "yes" && anpdFineSource && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mt-6 rounded-2xl border border-slate-800 bg-slate-950/25 p-5 md:p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-5 md:flex-row md:items-start md:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-3xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "section-kicker",
										children: "Referência regulatória"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-1 text-lg font-bold text-white",
										children: "Quando há dados pessoais, o impacto pode ir além da indisponibilidade"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-sm leading-relaxed text-slate-300",
										children: [
											"A LGPD também pode gerar obrigações administrativas conforme o tipo de dado, a ocorrência e as circunstâncias do caso. Como referência real, em 2023 a ANPD aplicou sua primeira multa a uma empresa privada: a microempresa Telekall Infoservice recebeu duas multas simples que totalizaram ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "text-slate-100",
												children: "R$ 14.400"
											}),
											", além de advertência."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs leading-relaxed text-slate-500",
										children: "O caso é específico e não representa uma estimativa de eventual sanção para esta empresa. A ANPD possui regras próprias de dosimetria e tratamento diferenciado para agentes de pequeno porte."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shrink-0 space-y-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: anpdFineSource.sourceUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "block font-semibold text-teal-400 transition hover:text-teal-300",
									children: "Ver caso oficial da ANPD"
								}), anpdSmallBusinessSource && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: anpdSmallBusinessSource.sourceUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "block font-semibold text-slate-400 transition hover:text-slate-300",
									children: "Regras para agentes de pequeno porte"
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "glass-card mt-6 p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "section-kicker",
								children: "Próximos passos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 text-xl font-bold text-white",
								children: "Por onde começar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-400 mt-1 mb-6",
								children: "Uma ordem prática para revisar os pontos identificados no diagnóstico."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 md:grid-cols-3",
								children: [
									immediatePriority && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl border border-amber-900/20 bg-amber-950/5 p-4 flex flex-col justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-3xs font-bold uppercase tracking-wider text-amber-400 block",
												children: "1. Primeiro ponto a revisar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "mt-2 font-bold text-slate-100 text-sm",
												children: priorityExecName[immediatePriority.key]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-2xs text-slate-400 mt-1",
												children: "Este foi o ponto que mais chamou atenção. Vale começar confirmando como ele funciona hoje e quais melhorias realmente fazem sentido para a empresa."
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 text-xs font-bold text-amber-300",
											children: [
												"Indicador atual: ",
												immediatePriority.score,
												"/100"
											]
										})]
									}),
									nextOpportunity && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl border border-cyan-900/10 bg-cyan-950/5 p-4 flex flex-col justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-3xs font-bold uppercase tracking-wider text-cyan-400 block",
												children: "2. Próximo ponto a revisar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "mt-2 font-bold text-slate-100 text-sm",
												children: priorityExecName[nextOpportunity.key]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-2xs text-slate-400 mt-1",
												children: "Depois do primeiro ponto, este é o próximo tema que vale revisar para reduzir dependências e melhorar a previsibilidade da operação."
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 text-xs font-bold text-cyan-300",
											children: [
												"Indicador atual: ",
												nextOpportunity.score,
												"/100"
											]
										})]
									}),
									mostMature && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl border border-emerald-900/15 bg-emerald-950/5 p-4 flex flex-col justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-3xs font-bold uppercase tracking-wider text-emerald-400 block",
												children: "3. Área com melhor condição atual"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "mt-2 font-bold text-slate-100 text-sm",
												children: priorityExecName[mostMature.key]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-2xs text-slate-400 mt-1",
												children: mostMature.score < 60 ? "Entre os pontos avaliados, este apresentou a melhor condição relativa, mas ainda há espaço importante para evolução. Vale revisar se a proteção atual oferece os recursos necessários para o ambiente e para os riscos da empresa." : mostMature.score < 80 ? "Este ponto apresenta uma base mais estruturada, mas ainda vale revisar lacunas e confirmar se os recursos atuais atendem às necessidades da empresa." : "Este ponto apresenta uma condição mais madura. A recomendação é manter os controles existentes e revisá-los periodicamente para garantir que continuem adequados ao ambiente."
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 text-xs font-bold text-emerald-300",
											children: [
												"Indicador atual: ",
												mostMature.score,
												"/100"
											]
										})]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mt-8 rounded-2xl border border-teal-950/30 bg-teal-950/10 p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-4 items-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 place-items-center rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-400 shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 20 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold text-white text-base",
									children: "Próxima etapa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 text-sm leading-relaxed text-slate-300",
									children: "A equipe Concierge pode usar este diagnóstico como ponto de partida para confirmar as informações, tirar dúvidas e entender quais melhorias realmente fazem sentido para o seu ambiente."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex flex-col gap-3 sm:flex-row sm:items-center",
									"data-pdf-ignore": "true",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: handleDownloadReport,
										disabled: isPdfGenerating,
										className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-teal-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-teal-950/30 transition hover:bg-teal-500 disabled:cursor-wait disabled:bg-teal-800 disabled:text-teal-200",
										children: isPdfGenerating ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
											size: 18,
											className: "animate-spin"
										}), "Preparando relatório..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 18 }), "Baixar relatório em PDF"] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs leading-relaxed text-slate-500",
										children: "O PDF reúne o mesmo diagnóstico exibido nesta página e inclui os detalhes técnicos dos principais pontos para facilitar o compartilhamento interno."
									})]
								})
							] })]
						})
					})
				]
			}),
			isDiagnosisModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				onMouseDown: (event) => {
					if (event.target === event.currentTarget) setIsDiagnosisModalOpen(false);
				},
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 md:p-8 relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setIsDiagnosisModalOpen(false),
							className: "absolute top-4 right-4 text-slate-500 hover:text-white transition",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 20 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-bold text-white",
							children: "Como chegamos a esta conclusão?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-slate-400",
							children: "A leitura usa as mesmas respostas do diagnóstico e as transforma em uma explicação mais simples sobre o que está funcionando, o que merece revisão e por onde faz sentido começar."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-4 text-sm text-slate-300",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "text-slate-100",
										children: "1. Respostas fornecidas"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-slate-400",
										children: "Consideramos apenas as informações declaradas no onboarding. Quando algum ponto importante não é conhecido, a leitura daquele domínio é marcada para validação adicional, sem transformar a ausência de informação em falha."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "text-slate-100",
										children: "2. Áreas analisadas"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-slate-400",
										children: "Organizamos as respostas em quatro áreas: internet e rede, computadores, dados e backup, e contas e acessos. O indicador mostra como essas áreas aparecem nas informações fornecidas."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "text-slate-100",
										children: "3. Ordem de atenção"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-slate-400",
										children: "Damos mais destaque aos pontos que aparecem mais frágeis nas respostas e ao impacto que eles podem ter no dia a dia. A ideia é mostrar de forma clara o que vale revisar primeiro."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "text-slate-100",
										children: "4. Referências"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-slate-400",
										children: "Frameworks como NIST CSF e CIS Controls orientam as capacidades avaliadas. Estatísticas de mercado só são exibidas quando previamente cadastradas e validadas na biblioteca de evidências do produto. Os pesos e faixas de score pertencem ao modelo interno Concierge."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "border-t border-slate-800 pt-4 text-xs leading-relaxed text-slate-500",
									children: "Este material é um diagnóstico inicial, comercial e executivo. Ele não substitui validação técnica, auditoria, teste de segurança, laudo pericial ou parecer jurídico."
								})
							]
						})
					]
				})
			}),
			isScoreModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				onMouseDown: (event) => {
					if (event.target === event.currentTarget) setIsScoreModalOpen(false);
				},
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 md:p-8 relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setIsScoreModalOpen(false),
							className: "absolute top-4 right-4 text-slate-500 hover:text-white transition",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 20 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-bold text-white",
							children: "Como calculamos o indicador"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-slate-400",
							children: "O indicador é calculado a partir das respostas fornecidas e de uma metodologia própria do Concierge Security Assessment, apoiada em boas práticas reconhecidas."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-5 text-sm text-slate-300",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-semibold text-slate-200",
									children: "Como tratamos suas respostas"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 leading-relaxed",
									children: [
										"O resultado consolidado considera apenas os controles que puderam ser avaliados pelas respostas fornecidas. Respostas ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "\"Não sei informar\"" }),
										" não são tratadas como falha ou penalidade. Elas indicam que aquele ponto precisa de confirmação adicional, evitando conclusões baseadas em hipóteses."
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-semibold text-slate-200",
									children: "O que a metodologia considera"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-2 space-y-1 text-xs list-disc list-inside text-slate-400",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Internet e rede:" }), " tipo de proteção utilizada, recursos de bloqueio, atualização e acompanhamento dos alertas."] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Computadores:" }), " antivírus, administração da proteção, atualizações, controle dos equipamentos e acompanhamento dos alertas."] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Dados e backup:" }), " existência das cópias, proteção contra exclusão ou alteração e teste de recuperação."] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Contas e segurança:" }), " verificação em duas etapas, contas compartilhadas, remoção de acessos, proteção de e-mail e definição de quem agir em um incidente."] })
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-semibold text-slate-200",
									children: "Faixas do indicador"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-2 space-y-1 text-xs text-slate-400",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"🟢 ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "80 - 100:" }),
											" Avançada"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"🔵 ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "65 - 79:" }),
											" Adequada"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"🟡 ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "45 - 64:" }),
											" Intermediária"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"🟠 ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "25 - 44:" }),
											" Básica"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"🔴 ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "0 - 24:" }),
											" Muito baixa"
										] })
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-4 border-t border-slate-800",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-semibold text-teal-400",
											children: "Referências metodológicas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 leading-relaxed text-xs text-slate-400",
											children: "A seleção dos controles avaliados foi estruturada com referência em frameworks amplamente utilizados em segurança da informação."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
											className: "mt-2 space-y-2 text-xs text-slate-400",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													className: "text-teal-400 hover:text-teal-300",
													href: "https://www.nist.gov/cyberframework",
													target: "_blank",
													rel: "noreferrer",
													children: "NIST Cybersecurity Framework (CSF 2.0)"
												}), " — organização de capacidades de governança, proteção, detecção, resposta e recuperação."] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													className: "text-teal-400 hover:text-teal-300",
													href: "https://www.cisecurity.org/controls",
													target: "_blank",
													rel: "noreferrer",
													children: "CIS Critical Security Controls"
												}), " — conjunto priorizado de controles técnicos e operacionais."] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													className: "text-teal-400 hover:text-teal-300",
													href: "https://www.gov.br/anpd/pt-br",
													target: "_blank",
													rel: "noreferrer",
													children: "ANPD / LGPD"
												}), " — utilizada apenas quando o diagnóstico tratar de proteção de dados e obrigações regulatórias."] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 leading-relaxed text-xs text-slate-500",
											children: "As referências orientam quais capacidades são avaliadas. Os pesos, notas, faixas de maturidade e severidades pertencem ao modelo interno Concierge. Estatísticas de mercado só aparecem quando cadastradas e validadas previamente na biblioteca de evidências do produto."
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-4 border-t border-slate-800",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-semibold text-slate-300",
										children: "Limitações"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-slate-500 leading-relaxed",
										children: "Este indicador é uma referência inicial baseada nas informações declaradas. Ele não é uma nota oficial do NIST ou CIS e não substitui auditoria, teste técnico, laudo pericial ou parecer jurídico."
									})]
								})
							]
						})
					]
				})
			}),
			isFaixaModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				onMouseDown: (event) => {
					if (event.target === event.currentTarget) setIsFaixaModalOpen(false);
				},
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "glass-card max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 md:p-8 relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setIsFaixaModalOpen(false),
							className: "absolute top-4 right-4 text-slate-500 hover:text-white transition",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 20 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-bold text-white",
							children: "Composição da Estimativa de Indisponibilidade"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-slate-400",
							children: "Veja a composição matemática do cálculo de impacto simulado no relatório."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-5 text-sm text-slate-300",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-semibold text-slate-200",
									children: "Fórmula de Impacto"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 bg-slate-950/60 p-3 rounded-lg border border-slate-900 font-mono text-xs text-teal-300",
									children: "Custo Total = (Pessoas × Horas de Parada × Custo/Hora) + Custo de Reconstrução + Custo Operacional Adicional"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-semibold text-slate-200",
									children: "Composição de Valores"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-xs text-slate-300",
											children: "Dados Declarados pelo Cliente"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-emerald-500/10 text-emerald-400 px-2 py-0.5 text-3xs font-semibold uppercase tracking-wider border border-emerald-500/10",
											children: "Dado informado pelo cliente"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "space-y-1 text-xs text-slate-400 list-disc list-inside",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
												"Pessoas: ",
												rangeLabel(draftData.users, "people"),
												" (referência usada na simulação: ",
												r.impactAssumptions.people,
												")"
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
												"Horas de Parada (baseadas no tempo tolerável): ",
												r.impactAssumptions.hours,
												"h"
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Computadores: ", rangeLabel(draftData.endpointCount || draftData.devices, "devices")] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Unidades operacionais: ", draftData.sites || 1] })
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-xs text-slate-300",
												children: "Premissas Referenciais"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-cyan-500/10 text-cyan-400 px-2 py-0.5 text-3xs font-semibold uppercase tracking-wider border border-cyan-500/10",
												children: "Premissa referencial Concierge"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
											className: "space-y-1 text-xs text-slate-400 list-disc list-inside",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
													"Custo operacional horário por colaborador: ",
													money(35),
													" a ",
													money(65),
													"/h"
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
													"Reconstrução técnica e suporte externo (estimado): ",
													money(2e3),
													" a ",
													money(6e3)
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
													"Custo de impacto operacional adicional (riscos / sistemas críticos): ",
													money(draftData.sensitiveData === "yes" ? 2500 : 1e3),
													" a ",
													money(draftData.sensitiveData === "yes" ? 7e3 : 4e3)
												] })
											]
										})]
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 border-t border-slate-800 text-xs text-slate-500 leading-relaxed",
									children: "Esta simulação utiliza informações declaradas pelo cliente e premissas referenciais internas da Concierge para construir uma ordem de grandeza operacional. Os valores não representam previsão de perda, garantia de impacto ou orçamento de recuperação. As premissas devem ser revisadas antes do uso em produção e podem ser ajustadas conforme o contexto do cliente."
								})
							]
						})
					]
				})
			})
		]
	});
}
var SplitComponent = ClientResults;
//#endregion
export { SplitComponent as component };
