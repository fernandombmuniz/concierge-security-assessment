//#region node_modules/.nitro/vite/services/ssr/assets/logo-concierge-CrmPVOHM.js
var logo_concierge_default = "/assets/logo-concierge-CwdLN5d7.jpg";
//#endregion
export { logo_concierge_default as t };
