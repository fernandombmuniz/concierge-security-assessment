import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useNavigate, g as Link, l as useRouterState, v as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-compat-D1jUaSai.js
var import_jsx_runtime = require_jsx_runtime();
/**
* Camada de compatibilidade de roteamento.
*
* O projeto original usava react-router-dom. Aqui expomos a mesma API mínima
* (Link, useNavigate, useSearchParams, useLocation, useParams) implementada
* sobre o TanStack Router, preservando o comportamento e o visual existentes.
*/
function splitTo(to) {
	const [pathname, query = ""] = to.split("?");
	const search = {};
	new URLSearchParams(query).forEach((value, key) => {
		search[key] = value;
	});
	return {
		pathname: pathname || "/",
		search
	};
}
function Link$1({ to, children, replace, ...rest }) {
	const { pathname, search } = splitTo(to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: pathname,
		search,
		replace,
		...rest,
		children
	});
}
function useNavigate$1() {
	const navigate = useNavigate();
	return (to, opts) => {
		const { pathname, search } = splitTo(to);
		navigate({
			to: pathname,
			search,
			replace: opts?.replace
		});
	};
}
function useLocation() {
	return useRouterState({ select: (state) => ({
		pathname: state.location.pathname,
		search: state.location.searchStr ?? ""
	}) });
}
function useSearchParams() {
	const searchStr = useRouterState({ select: (state) => state.location.searchStr ?? "" });
	return [new URLSearchParams(searchStr)];
}
function useParams$1() {
	return useParams({ strict: false });
}
//#endregion
export { useSearchParams as a, useParams$1 as i, useLocation as n, useNavigate$1 as r, Link$1 as t };
