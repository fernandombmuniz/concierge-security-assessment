import { a as stringType, i as objectType } from "../_libs/zod.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-BFFE07zL.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-UH_Jp6hR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/internal.functions-CJBtjQJY.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Área interna: leitura dos assessments gravados no banco.
*
* O vínculo entre o usuário autenticado e o registro de Account Manager é
* feito por e-mail no primeiro acesso, para que a RLS reconheça o AM.
*/
async function linkManager(userId, email) {
	if (!email) return;
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	await supabaseAdmin.from("account_managers").update({ user_id: userId }).eq("email", email.toLowerCase()).is("user_id", null);
}
var listInternalAssessments_createServerFn_handler = createServerRpc({
	id: "9ca52ce4aa10b3440afc94c3046896e5a7f57e15d698cb475e4f862a07a6ab74",
	name: "listInternalAssessments",
	filename: "src/lib/internal.functions.ts"
}, (opts) => listInternalAssessments.__executeServer(opts));
var listInternalAssessments = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listInternalAssessments_createServerFn_handler, async ({ context }) => {
	const email = context.claims?.email ?? null;
	await linkManager(context.userId, email);
	const { data, error } = await context.supabase.from("assessments").select("id, company_name, respondent_name, respondent_email, sector, status, overall_score, priority_domain_label, maturity_level, coverage_percentage, public_ref, source, created_at, completed_at").order("created_at", { ascending: false }).limit(200);
	if (error) throw new Error("Não foi possível carregar os assessments.");
	return {
		items: data ?? [],
		email
	};
});
var getInternalAssessment_createServerFn_handler = createServerRpc({
	id: "d41e6b99bc0389cbedfde2a2806fdb442b5c1613d9a71de862845630da2a7a90",
	name: "getInternalAssessment",
	filename: "src/lib/internal.functions.ts"
}, (opts) => getInternalAssessment.__executeServer(opts));
var getInternalAssessment = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).inputValidator((input) => objectType({ id: stringType().uuid() }).parse(input)).handler(getInternalAssessment_createServerFn_handler, async ({ data, context }) => {
	const email = context.claims?.email ?? null;
	await linkManager(context.userId, email);
	const { data: assessment } = await context.supabase.from("assessments").select("id, created_at, completed_at, status, public_ref, source").eq("id", data.id).maybeSingle();
	if (!assessment) return { found: false };
	const { data: response } = await context.supabase.from("assessment_responses").select("answers").eq("assessment_id", data.id).eq("section", "completo").maybeSingle();
	return {
		found: true,
		assessment,
		answersJson: JSON.stringify(response?.answers ?? {})
	};
});
//#endregion
export { getInternalAssessment_createServerFn_handler, listInternalAssessments_createServerFn_handler };
