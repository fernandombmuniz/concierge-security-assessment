import { r as scoreAssessment, t as emptyAssessment } from "./scoring-CLIBbsft.mjs";
import { a as stringType, i as objectType, n as coerce, r as enumType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assessment-session-CXBePsz7.js
var text = (max = 500) => stringType().max(max).catch("");
var num = coerce.number().finite().min(0).max(1e7).catch(0);
var enumOf = (values, fallback) => enumType(values).catch(fallback);
/**
* Valida e normaliza no servidor o mesmo formato
* utilizado pelo formulário do Security Assessment.
*/
var assessmentDataSchema = objectType({
	companyName: text(200),
	sector: text(120),
	sectorOther: text(120),
	contactName: text(160),
	contactRole: text(160),
	contactEmail: text(200),
	users: num,
	devices: num,
	itTeamSize: num,
	sites: num,
	internetLinkCount: num,
	links: arrayType(objectType({ speedMbps: num })).max(20).catch([{ speedMbps: 0 }]),
	networkUsage: enumOf([
		"light",
		"medium",
		"high"
	], "medium"),
	firewallLevel: enumOf([
		"none",
		"isp",
		"router",
		"utm",
		"ngfw",
		"managed_ngfw",
		"unknown"
	], "unknown"),
	firewallVendor: text(120),
	firewallModel: text(120),
	firewallLicense: enumOf([
		"yes",
		"no",
		"unknown"
	], "unknown"),
	vpnRemote: num,
	vpnSite: num,
	vlans: num,
	monitoring: enumOf([
		"none",
		"reactive_it",
		"outsourced_it",
		"security_team",
		"soc",
		"unknown"
	], "unknown"),
	firewallThreatPrevention: enumOf([
		"yes",
		"partial",
		"no",
		"unknown"
	], "unknown"),
	networkMaintenance: enumOf([
		"formal",
		"informal",
		"none",
		"unknown"
	], "unknown"),
	endpointLevel: enumOf([
		"none",
		"basic_av",
		"business_av",
		"edr",
		"managed_edr",
		"unknown"
	], "unknown"),
	endpointCount: num,
	servers: num,
	autoUpdates: enumOf([
		"yes",
		"no",
		"unknown"
	], "unknown"),
	localAdmins: enumOf([
		"yes",
		"no",
		"unknown"
	], "unknown"),
	byod: enumOf([
		"yes",
		"no",
		"unknown"
	], "unknown"),
	endpointCentralManagement: enumOf([
		"yes",
		"partial",
		"no",
		"unknown"
	], "unknown"),
	endpointResponse: enumOf([
		"managed_soc",
		"defined_team",
		"alerts_only",
		"none",
		"unknown"
	], "unknown"),
	assetInventory: enumOf([
		"managed",
		"partial",
		"informal",
		"none",
		"unknown"
	], "unknown"),
	vulnerabilityManagement: enumOf([
		"continuous",
		"regular",
		"occasional",
		"reactive",
		"none",
		"unknown"
	], "unknown"),
	dataLocation: enumOf([
		"corporate_central",
		"mixed",
		"endpoints",
		"personal_cloud",
		"saas_only",
		"unknown"
	], "unknown"),
	backupLevel: enumOf([
		"none",
		"manual",
		"automated_local",
		"cloud",
		"multi_copy",
		"managed",
		"unknown"
	], "unknown"),
	backupVolumeGb: num,
	restoreTests: enumOf([
		"regular",
		"once",
		"never",
		"unknown"
	], "unknown"),
	maxDowntime: enumOf([
		"4h",
		"8h",
		"1d",
		"2d",
		"more",
		"unknown"
	], "unknown"),
	backupIsolation: enumOf([
		"immutable",
		"isolated",
		"separate_account",
		"same_environment",
		"none",
		"unknown"
	], "unknown"),
	mfa: enumOf([
		"yes",
		"partial",
		"no",
		"unknown"
	], "unknown"),
	sharedAccounts: enumOf([
		"yes",
		"no",
		"unknown"
	], "unknown"),
	offboarding: enumOf([
		"formal",
		"informal",
		"unknown"
	], "unknown"),
	emailProtection: enumOf([
		"advanced",
		"standard",
		"basic",
		"none",
		"unknown"
	], "unknown"),
	incidentResponse: enumOf([
		"formal",
		"informal",
		"none",
		"unknown"
	], "unknown"),
	criticalSystems: arrayType(stringType().max(160)).max(50).catch([]),
	sensitiveData: enumOf([
		"yes",
		"no",
		"unknown"
	], "unknown"),
	incidentHistory: enumOf([
		"yes",
		"no",
		"unknown"
	], "unknown"),
	mainConcern: text(500),
	notes: text(4e3)
});
function parseAssessmentData(input) {
	const merged = {
		...emptyAssessment,
		...typeof input === "object" && input ? input : {}
	};
	return assessmentDataSchema.parse(merged);
}
var PRIVACY_NOTICE_VERSION = "2026-01";
function getSupabaseUrl() {
	const url = {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "otytofbozhmvptthzyxi",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_9Uu1KGsS8SDJbLdh3ypkEw_HY6uEWZM",
		"VITE_SUPABASE_URL": "https://otytofbozhmvptthzyxi.supabase.co"
	}["VITE_SUPABASE_URL"];
	if (!url) throw new Error("VITE_SUPABASE_URL não configurada.");
	return url.replace(/\/$/, "");
}
function getPublishableKey() {
	const key = {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "otytofbozhmvptthzyxi",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_9Uu1KGsS8SDJbLdh3ypkEw_HY6uEWZM",
		"VITE_SUPABASE_URL": "https://otytofbozhmvptthzyxi.supabase.co"
	}["VITE_SUPABASE_PUBLISHABLE_KEY"];
	if (!key) throw new Error("VITE_SUPABASE_PUBLISHABLE_KEY não configurada.");
	return key;
}
function getAssessmentApiUrl() {
	return `${getSupabaseUrl()}/functions/v1/assessment-api`;
}
async function callAssessmentApi(payload) {
	const response = await fetch(getAssessmentApiUrl(), {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			apikey: getPublishableKey()
		},
		body: JSON.stringify(payload)
	});
	let body = {};
	try {
		body = await response.json();
	} catch {}
	if (!response.ok || body.success === false) throw new Error(body.error ?? `Falha na comunicação com o Security Assessment (${response.status}).`);
	return body;
}
async function startAssessment({ data }) {
	if (!data.consent) throw new Error("Consentimento obrigatório.");
	const result = await callAssessmentApi({
		action: "create",
		ref: data.ref ?? null,
		source: data.source ?? null,
		privacyNoticeVersion: PRIVACY_NOTICE_VERSION,
		consentAt: (/* @__PURE__ */ new Date()).toISOString()
	});
	if (!result.assessmentId || !result.publicToken) throw new Error("A API não retornou uma sessão válida.");
	return {
		assessmentId: result.assessmentId,
		editToken: result.publicToken
	};
}
async function saveAssessmentProgress({ data }) {
	const parsed = parseAssessmentData(data.data);
	return { savedAt: (await callAssessmentApi({
		action: "save",
		assessmentId: data.assessmentId,
		publicToken: data.editToken,
		answers: parsed,
		currentStep: data.step
	})).savedAt ?? (/* @__PURE__ */ new Date()).toISOString() };
}
async function completeAssessment({ data }) {
	const parsed = parseAssessmentData(data.data);
	const result = scoreAssessment(parsed);
	return {
		ok: true,
		completedAt: (await callAssessmentApi({
			action: "complete",
			assessmentId: data.assessmentId,
			publicToken: data.editToken,
			answers: parsed,
			result: {
				overallScore: result.overall,
				networkScore: result.scores.network,
				endpointScore: result.scores.endpoint,
				continuityScore: result.scores.backup,
				identityScore: result.scores.identity,
				coveragePercent: result.completeness,
				priorityDomain: result.priority,
				methodologyVersion: "v3.2",
				findings: result.findings,
				scoringSnapshot: result
			}
		})).completedAt ?? (/* @__PURE__ */ new Date()).toISOString()
	};
}
/**
* Sessão do assessment no navegador.
*
* Guarda apenas o identificador e o token de edição do próprio respondente,
* permitindo salvar as respostas no banco em tempo real sem exigir login.
* O rascunho local existente continua funcionando exatamente como antes.
*/
var KEY = "concierge-assessment-session-v1";
function loadSession() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return parsed?.assessmentId && parsed?.editToken ? parsed : null;
	} catch {
		return null;
	}
}
function saveSession(session) {
	localStorage.setItem(KEY, JSON.stringify(session));
}
function clearSession() {
	localStorage.removeItem(KEY);
}
var ATTRIBUTION_KEY = "concierge-assessment-attribution-v1";
/**
* Define uma atribuição limpa para um novo assessment público.
*
* Diferente de rememberAttribution(), valores ausentes não são herdados do
* respondente anterior. Isso impede, por exemplo, que um `src` antigo seja
* associado a um novo cliente que abriu apenas `?ref=fernando`.
*/
function resetAttribution(ref, source) {
	if (typeof window === "undefined") return;
	localStorage.setItem(ATTRIBUTION_KEY, JSON.stringify({
		ref,
		source
	}));
}
function readAttribution() {
	if (typeof window === "undefined") return {
		ref: null,
		source: null
	};
	try {
		const parsed = JSON.parse(localStorage.getItem(ATTRIBUTION_KEY) || "{}");
		return {
			ref: parsed.ref ?? null,
			source: parsed.source ?? null
		};
	} catch {
		return {
			ref: null,
			source: null
		};
	}
}
//#endregion
export { resetAttribution as a, startAssessment as c, readAttribution as i, completeAssessment as n, saveAssessmentProgress as o, loadSession as r, saveSession as s, clearSession as t };
