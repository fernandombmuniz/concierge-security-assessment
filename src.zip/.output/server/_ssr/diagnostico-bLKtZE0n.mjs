import { i as __toESM } from "../_runtime.mjs";
import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { S as Building2, T as ArrowLeft, c as MonitorSmartphone, d as KeyRound, f as Info, h as Database, n as Wifi, u as LoaderCircle, v as CircleCheck, w as ArrowRight } from "../_libs/lucide-react.mjs";
import { r as useNavigate$1 } from "./router-compat-D1jUaSai.mjs";
import { a as saveDraft, i as loadDraft, o as saveSubmission, t as ClientHeader } from "./ClientHeader-DBh3ZhLU.mjs";
import { n as completeAssessment, o as saveAssessmentProgress, r as loadSession } from "./assessment-session-CXBePsz7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diagnostico-bLKtZE0n.js
init_performance();
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Card = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "glass-card p-6 md:p-8",
	children
});
var Field = ({ label, help, children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
	className: "question-field flex h-full flex-col",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "question-label flex min-h-0 items-end font-semibold leading-snug text-slate-100 md:min-h-[2.9rem]",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "question-control mt-2",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "question-help mt-2 block min-h-0 text-sm leading-relaxed text-slate-400 md:min-h-[2.6rem]",
			children: help || ""
		})
	]
});
var QuestionPair = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "grid gap-5 md:grid-cols-2 md:items-stretch",
	children
});
var StepSection = ({ eyebrow, title, description, children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
	className: "rounded-2xl border border-slate-800/80 bg-slate-950/20 p-5 md:p-6",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 border-b border-slate-800/70 pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-2xs font-bold uppercase tracking-[.16em] text-teal-400",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-1 text-lg font-bold text-slate-100",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-slate-400",
				children: description
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-5",
		children
	})]
});
var input = "w-full rounded-xl border border-slate-700/80 bg-slate-950/65 px-4 py-3.5 text-slate-100 shadow-inner outline-none transition placeholder:text-slate-600 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/10";
var select = input;
var sectors = [
	"Saúde",
	"Advocacia",
	"Contabilidade",
	"Construção / Engenharia",
	"Indústria",
	"Varejo",
	"Distribuição / Atacado",
	"Transporte / Logística",
	"Hotelaria / Turismo",
	"Alimentação",
	"Educação",
	"Serviços Profissionais",
	"Tecnologia",
	"Financeiro",
	"Imobiliário",
	"Outros"
];
var firewallVendors = [
	"MikroTik",
	"Fortinet",
	"SonicWall",
	"Sophos",
	"WatchGuard",
	"Palo Alto Networks",
	"Cisco",
	"Check Point",
	"pfSense / OPNsense",
	"Ubiquiti",
	"Outro",
	"Não sei informar"
];
var peopleBucket = (n) => !n ? 0 : n <= 10 ? 5 : n <= 20 ? 15 : n <= 50 ? 35 : n <= 100 ? 75 : n <= 200 ? 150 : 250;
var deviceBucket = peopleBucket;
var serverBucket = (n) => !n ? 0 : n === 1 ? 1 : n <= 5 ? 3 : 6;
var teamBucket = (n) => !n ? 0 : n === 1 ? 1 : n <= 5 ? 3 : 6;
var backupBucket = (n) => !n ? 0 : n <= 100 ? 50 : n <= 500 ? 300 : n <= 1e3 ? 750 : n <= 5e3 ? 3e3 : 7500;
function AssessmentForm() {
	const nav = useNavigate$1();
	const [step, setStep] = (0, import_react.useState)(() => {
		const saved = localStorage.getItem("concierge-client-assessment-step-v2");
		return saved ? parseInt(saved, 10) : 0;
	});
	const [a, setA] = (0, import_react.useState)(() => loadDraft());
	const [vpnRemoteChoice, setVpnRemoteChoice] = (0, import_react.useState)(() => {
		if (a.vpnRemote > 20) return "most";
		if (a.vpnRemote > 5) return "some";
		if (a.vpnRemote > 0) return "few";
		return "unknown";
	});
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const set = (k, v) => setA((x) => ({
		...x,
		[k]: v
	}));
	(0, import_react.useEffect)(() => {
		localStorage.setItem("concierge-client-assessment-step-v2", String(step));
	}, [step]);
	(0, import_react.useEffect)(() => {
		const t = window.setTimeout(() => {
			saveDraft(a);
		}, 300);
		return () => window.clearTimeout(t);
	}, [a]);
	const steps = (0, import_react.useMemo)(() => [
		{
			name: "Empresa",
			icon: Building2,
			desc: "Sobre a empresa e quem utiliza a tecnologia"
		},
		{
			name: "Internet e rede",
			icon: Wifi,
			desc: "Como a conexão é protegida e acompanhada"
		},
		{
			name: "Computadores",
			icon: MonitorSmartphone,
			desc: "Como os computadores são protegidos no dia a dia"
		},
		{
			name: "Dados e backup",
			icon: Database,
			desc: "Onde estão os dados e como a empresa consegue recuperá-los"
		},
		{
			name: "Contas e segurança",
			icon: KeyRound,
			desc: "Acessos, e-mail e preparação para incidentes"
		}
	], []);
	const snapshot = JSON.stringify(a);
	(0, import_react.useEffect)(() => {
		const session = loadSession();
		if (!session) return;
		const t = setTimeout(() => {
			saveAssessmentProgress({ data: {
				assessmentId: session.assessmentId,
				editToken: session.editToken,
				step,
				data: JSON.parse(snapshot)
			} }).catch(() => {});
		}, 900);
		return () => clearTimeout(t);
	}, [snapshot, step]);
	const submit = async () => {
		if (isSubmitting) return;
		const startedAt = performance_default.now();
		const minimumTransitionMs = 950;
		setIsSubmitting(true);
		const session = loadSession();
		saveDraft(a);
		if (!session) {
			alert("Não encontramos a sessão deste diagnóstico. Suas respostas continuam salvas neste dispositivo.");
			setIsSubmitting(false);
			return;
		}
		try {
			await completeAssessment({ data: {
				assessmentId: session.assessmentId,
				editToken: session.editToken,
				data: a
			} });
			const elapsed = performance_default.now() - startedAt;
			const remaining = Math.max(0, minimumTransitionMs - elapsed);
			if (remaining > 0) await new Promise((resolve) => setTimeout(resolve, remaining));
			const s = saveSubmission(a);
			nav(`/resultado?id=${s.id}&success=true`);
		} catch (error) {
			console.error("Falha ao concluir assessment:", error);
			alert("Não foi possível enviar o diagnóstico neste momento. Suas respostas continuam salvas neste dispositivo. Verifique sua conexão e tente novamente.");
			setIsSubmitting(false);
		}
	};
	const current = steps[step];
	const firewallVendorValue = firewallVendors.includes(a.firewallVendor) ? a.firewallVendor : a.firewallVendor ? "Outro" : "Não sei informar";
	const sectorValue = sectors.includes(a.sector) ? a.sector : a.sector ? "Outros" : "";
	const sectorOtherValue = a.sector === "Outros" ? a.sectorOther : !sectors.includes(a.sector) ? a.sector : a.sectorOther;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-dashboard-animate bg-grid-tech px-4 py-7 md:py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-6 grid grid-cols-5 gap-2",
					children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1.5 rounded-full transition ${i <= step ? "bg-gradient-to-r from-cyan-500 to-teal-400" : "bg-slate-800"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `mt-2 hidden text-xs md:block ${i === step ? "font-semibold text-teal-300" : "text-slate-600"}`,
						children: s.name
					})] }, s.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-7 flex flex-col justify-between gap-4 border-b border-slate-800 pb-6 sm:flex-row sm:items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-teal-500/20 bg-teal-500/10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(current.icon, { className: "text-teal-300" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs font-bold uppercase tracking-[.18em] text-teal-400",
									children: [
										"Etapa ",
										step + 1,
										" de ",
										steps.length
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-2xl font-bold",
									children: current.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-slate-400",
									children: [current.desc, ". Preencha apenas o que souber. “Não sei informar” é uma resposta válida."]
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex shrink-0 items-center gap-1.5 self-end rounded-lg border border-slate-800/60 bg-slate-900/40 px-3 py-1.5 text-xs text-slate-500 sm:self-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block h-1.5 w-1.5 rounded-full bg-teal-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Respostas salvas automaticamente" })]
						})]
					}),
					step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nome da empresa",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: input,
									value: a.companyName,
									onChange: (e) => set("companyName", e.target.value),
									placeholder: "Ex.: Empresa ABC"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Setor de atuação",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: sectorValue,
										onChange: (e) => {
											set("sector", e.target.value);
											if (e.target.value !== "Outros") set("sectorOther", "");
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Selecione o setor"
										}), sectors.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: s,
											children: s
										}, s))]
									}), sectorValue === "Outros" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: input,
										value: sectorOtherValue,
										onChange: (e) => set("sectorOther", e.target.value),
										placeholder: "Informe o setor",
										"aria-label": "Qual é o setor de atuação?"
									})]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Seu nome",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: input,
									value: a.contactName,
									onChange: (e) => set("contactName", e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Cargo",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: input,
									value: a.contactRole,
									onChange: (e) => set("contactRole", e.target.value)
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "E-mail",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: input,
									type: "email",
									value: a.contactEmail,
									onChange: (e) => set("contactEmail", e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Quantas pessoas utilizam computadores, sistemas ou a rede da empresa?",
								help: "Considere funcionários e colaboradores que utilizam os recursos de TI regularmente.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: peopleBucket(a.users),
									onChange: (e) => set("users", +e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0",
											children: "Selecione uma faixa"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "5",
											children: "Até 10 pessoas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "15",
											children: "11 a 20 pessoas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "35",
											children: "21 a 50 pessoas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "75",
											children: "51 a 100 pessoas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "150",
											children: "101 a 200 pessoas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "250",
											children: "Mais de 200 pessoas"
										})
									]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Quantas unidades ou filiais a empresa possui?",
								help: "Considere matriz, filiais ou unidades que façam parte deste diagnóstico.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: input,
									type: "number",
									min: "1",
									value: a.sites,
									onChange: (e) => set("sites", +e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Quem cuida da TI no dia a dia?",
								help: "Isso ajuda a entender quem normalmente administra equipamentos, sistemas e acessos.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: teamBucket(a.itTeamSize),
									onChange: (e) => set("itTeamSize", +e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0",
											children: "Não há equipe interna / não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1",
											children: "1 pessoa interna"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "3",
											children: "2 a 5 pessoas internas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "6",
											children: "Mais de 5 pessoas internas"
										})
									]
								})
							})] })
						]
					}),
					step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StepSection, {
							eyebrow: "Parte 1 de 2",
							title: "Proteção e acompanhamento",
							description: "Primeiro, queremos entender como a rede é protegida e quem acompanha os alertas de segurança.",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Como a empresa protege hoje a conexão com a internet?",
									help: "Escolha a opção mais próxima do que existe hoje. Se não souber, tudo bem.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: a.firewallLevel,
										onChange: (e) => set("firewallLevel", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "none",
												children: "Não existe uma proteção dedicada além do roteador comum"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "isp",
												children: "Usa apenas o equipamento fornecido pela operadora"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "router",
												children: "Usa MikroTik ou outro roteador corporativo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "utm",
												children: "Usa um equipamento próprio para proteger a rede"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "ngfw",
												children: "Usa uma solução de segurança com bloqueios e proteções adicionais"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "managed_ngfw",
												children: "Usa uma solução de segurança acompanhada por equipe especializada"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Quando algo suspeito acontece na rede, quem costuma receber ou verificar os alertas?",
									help: "Queremos saber se alguém acompanha o que acontece, e não apenas se existe um equipamento instalado.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: a.monitoring,
										onChange: (e) => set("monitoring", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "none",
												children: "Ninguém acompanha regularmente"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "reactive_it",
												children: "Equipe de TI verifica quando necessário"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "outsourced_it",
												children: "Empresa terceirizada de TI"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "security_team",
												children: "Equipe especializada de segurança"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "soc",
												children: "Equipe especializada com acompanhamento contínuo"
											})
										]
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "A proteção da internet consegue bloquear ameaças além de simplesmente permitir ou negar acessos?",
									help: "Por exemplo: bloquear sites maliciosos, tentativas de ataque ou aplicações indevidas. Se não souber, escolha “Não sei informar”.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: a.firewallThreatPrevention,
										onChange: (e) => set("firewallThreatPrevention", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "yes",
												children: "Sim, existem vários bloqueios e proteções adicionais"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "partial",
												children: "Existem algumas proteções adicionais"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "no",
												children: "Não, atua principalmente controlando acessos"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Alguém revisa e atualiza regularmente os equipamentos que protegem a rede?",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: a.networkMaintenance,
										onChange: (e) => set("networkMaintenance", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "formal",
												children: "Sim, existe rotina definida"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "informal",
												children: "É feito quando necessário"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "none",
												children: "Não existe rotina definida"
											})
										]
									})
								})] }),
								![
									"none",
									"isp",
									"unknown"
								].includes(a.firewallLevel) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "A solução de segurança recebe atualizações e mantém os recursos contratados ativos?",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: a.firewallLicense,
										onChange: (e) => set("firewallLicense", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "yes",
												children: "Sim"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "no",
												children: "Não"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Marca do equipamento de segurança, se souber",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: select,
										value: firewallVendorValue,
										onChange: (e) => set("firewallVendor", e.target.value === "Não sei informar" ? "" : e.target.value),
										children: firewallVendors.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: v,
											children: v
										}, v))
									})
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [firewallVendorValue === "Outro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Outro fabricante",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: input,
										value: a.firewallVendor === "Outro" ? "" : a.firewallVendor,
										onChange: (e) => set("firewallVendor", e.target.value),
										placeholder: "Informe o fabricante"
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Modelo do equipamento, se souber",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: input,
										value: a.firewallModel,
										onChange: (e) => set("firewallModel", e.target.value),
										placeholder: "Ex.: 40F, TZ80, RB4011..."
									})
								})] })] })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StepSection, {
							eyebrow: "Parte 2 de 2",
							title: "Internet e conexão",
							description: "Agora alguns dados simples sobre a conexão. Se você não souber algum deles, pode deixar em branco.",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Quantas conexões de internet a empresa possui?",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: input,
										type: "number",
										min: "1",
										value: a.internetLinkCount,
										onChange: (e) => set("internetLinkCount", +e.target.value)
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Qual é aproximadamente a velocidade da internet da empresa?",
									help: "Escolha a opção mais próxima.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: !a.links[0]?.speedMbps ? "unknown" : a.links[0].speedMbps <= 100 ? "100" : a.links[0].speedMbps <= 300 ? "300" : a.links[0].speedMbps <= 500 ? "500" : a.links[0].speedMbps <= 1e3 ? "1000" : "1500",
										onChange: (e) => set("links", [{ speedMbps: e.target.value === "unknown" ? 0 : Number(e.target.value) }]),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "100",
												children: "Até 100 Mbps"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "300",
												children: "101 a 300 Mbps"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "500",
												children: "301 a 500 Mbps"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "1000",
												children: "501 Mbps a 1 Gbps"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "1500",
												children: "Mais de 1 Gbps"
											})
										]
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Como a internet é usada no dia a dia?",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: a.networkUsage,
										onChange: (e) => set("networkUsage", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "light",
												children: "Leve — navegação, e-mail, sistemas simples"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "medium",
												children: "Médio — cloud, videoconferência e uso frequente"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "high",
												children: "Intenso — alto tráfego, múltiplos serviços e transferências"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Pessoas acessam os sistemas da empresa de fora do escritório?",
									help: "Esse acesso pode ser feito por VPN ou outra forma de acesso remoto seguro.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: vpnRemoteChoice,
										onChange: (e) => {
											const choice = e.target.value;
											setVpnRemoteChoice(choice);
											set("vpnRemote", choice === "few" ? 3 : choice === "some" ? 10 : choice === "most" ? 25 : 0);
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "none",
												children: "Não"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "few",
												children: "Sim, poucas pessoas"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "some",
												children: "Sim, parte da equipe"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "most",
												children: "Sim, a maior parte da equipe"
											})
										]
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Existem conexões seguras entre matriz e filiais? Quantas?",
									help: "Considere conexões usadas para interligar unidades. Se não souber, deixe em branco.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: input,
										type: "number",
										min: "0",
										value: a.vpnSite || "",
										onChange: (e) => set("vpnSite", +e.target.value)
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "A rede da empresa é separada para diferentes tipos de uso?",
									help: "Por exemplo: funcionários, visitantes, servidores ou equipamentos específicos.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: select,
										value: a.vlans === 0 ? "unknown" : a.vlans === 1 ? "no" : a.vlans === 2 ? "partial" : "yes",
										onChange: (e) => set("vlans", e.target.value === "yes" ? 3 : e.target.value === "partial" ? 2 : e.target.value === "no" ? 1 : 0),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "unknown",
												children: "Não sei informar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "yes",
												children: "Sim"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "partial",
												children: "Parcialmente"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "no",
												children: "Não"
											})
										]
									})
								})] })
							]
						})]
					}),
					step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Os computadores da empresa utilizam antivírus ou outra proteção de segurança?",
								help: "Escolha a opção que mais se aproxima do que você conhece hoje.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.endpointLevel,
									onChange: (e) => set("endpointLevel", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe uma proteção padronizada"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "basic_av",
											children: "Sim, antivírus instalado individualmente"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "business_av",
											children: "Sim, antivírus corporativo administrado pela empresa ou TI"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "edr",
											children: "Sim, proteção avançada que também ajuda a investigar comportamentos suspeitos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "managed_edr",
											children: "Sim, proteção avançada que também ajuda a investigar comportamentos suspeitos acompanhado por equipe especializada"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Aproximadamente quantos computadores e notebooks a empresa utiliza?",
								help: "Escolha a opção mais próxima.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: deviceBucket(a.endpointCount || a.devices),
									onChange: (e) => {
										set("endpointCount", +e.target.value);
										set("devices", +e.target.value);
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0",
											children: "Selecione uma faixa"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "5",
											children: "Até 10 equipamentos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "15",
											children: "11 a 20 equipamentos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "35",
											children: "21 a 50 equipamentos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "75",
											children: "51 a 100 equipamentos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "150",
											children: "101 a 200 equipamentos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "250",
											children: "Mais de 200 equipamentos"
										})
									]
								})
							})] }),
							a.endpointLevel !== "none" && a.endpointLevel !== "unknown" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "O responsável pela TI consegue acompanhar e administrar a proteção dos computadores em um único lugar?",
								help: "Por exemplo, visualizar quais computadores estão protegidos, receber alertas e aplicar configurações de forma centralizada.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.endpointCentralManagement,
									onChange: (e) => set("endpointCentralManagement", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "yes",
											children: "Sim, todos ou quase todos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "partial",
											children: "Apenas parte dos equipamentos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "no",
											children: "Não"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Quando uma ameaça é detectada em um computador, alguém acompanha o que aconteceu?",
								help: "Queremos saber se existe alguém responsável por olhar o alerta e decidir o que precisa ser feito.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.endpointResponse,
									onChange: (e) => set("endpointResponse", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "managed_soc",
											children: "Uma equipe especializada acompanha e responde"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "defined_team",
											children: "Existe uma pessoa ou equipe definida para verificar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "alerts_only",
											children: "Existem alertas, mas são verificados apenas quando necessário"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe acompanhamento dos alertas"
										})
									]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "A empresa possui uma lista atualizada dos computadores, servidores e outros equipamentos usados no trabalho?",
								help: "Pode ser uma ferramenta, planilha ou outro controle que permita saber quais equipamentos existem e quem os utiliza.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.assetInventory,
									onChange: (e) => set("assetInventory", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "managed",
											children: "Sim, inventário atualizado e gerenciado"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "partial",
											children: "Existe, mas pode estar incompleto"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "informal",
											children: "Controle informal / planilha sem revisão regular"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe inventário"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block" })] }),
							(a.assetInventory !== "unknown" || [
								"business_av",
								"edr",
								"managed_edr"
							].includes(a.endpointLevel)) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "A empresa verifica periodicamente se computadores e sistemas precisam de atualizações ou correções de segurança?",
								help: "Pense em atualizações pendentes, versões antigas ou falhas que precisem ser corrigidas.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.vulnerabilityManagement,
									onChange: (e) => set("vulnerabilityManagement", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "continuous",
											children: "Monitoramento contínuo / ferramenta dedicada"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "regular",
											children: "Verificação periódica definida"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "occasional",
											children: "Verificações ocasionais"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "reactive",
											children: "Normalmente quando surge um problema"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe processo"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block" })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "A empresa possui servidores próprios?",
								help: "Considere servidores físicos ou virtuais administrados pela empresa.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: serverBucket(a.servers),
									onChange: (e) => set("servers", +e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0",
											children: "Não possui / não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1",
											children: "1 servidor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "3",
											children: "2 a 5 servidores"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "6",
											children: "Mais de 5 servidores"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Os computadores recebem atualizações de segurança automaticamente?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.autoUpdates,
									onChange: (e) => set("autoUpdates", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "yes",
											children: "Sim"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "no",
											children: "Não"
										})
									]
								})
							})] })
						]
					}),
					step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Onde ficam os arquivos e informações mais importantes da empresa?",
								help: "Pense onde as pessoas salvam documentos e informações usadas no dia a dia.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.dataLocation,
									onChange: (e) => set("dataLocation", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "corporate_central",
											children: "Em um local corporativo centralizado, como servidor, SharePoint ou OneDrive da empresa"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "saas_only",
											children: "Principalmente dentro de sistemas e aplicações em nuvem"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "mixed",
											children: "Espalhados entre nuvem da empresa, servidores e computadores"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "endpoints",
											children: "Principalmente nos computadores e notebooks das pessoas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "personal_cloud",
											children: "Em contas pessoais ou locais não administrados pela empresa"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block" })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "A empresa possui cópias de segurança dos dados importantes?",
								help: "Pense nos arquivos e sistemas que fariam falta se fossem perdidos ou apagados.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.backupLevel,
									onChange: (e) => set("backupLevel", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe uma rotina de cópia de segurança"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "manual",
											children: "Sim, mas as cópias são feitas manualmente"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "automated_local",
											children: "Sim, cópia automática em equipamento ou local da empresa"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "cloud",
											children: "Sim, cópia automática em nuvem"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "multi_copy",
											children: "Sim, existem cópias em mais de um local"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "managed",
											children: "Sim, existe uma rotina gerenciada e acompanhada"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Aproximadamente quanto de informação importante precisa ser protegida?",
								help: "Se não souber, escolha “Não sei informar”.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: backupBucket(a.backupVolumeGb),
									onChange: (e) => set("backupVolumeGb", +e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "0",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "50",
											children: "Até 100 GB"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "300",
											children: "100 a 500 GB"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "750",
											children: "500 GB a 1 TB"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "3000",
											children: "1 a 5 TB"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "7500",
											children: "Mais de 5 TB"
										})
									]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Existe pelo menos uma cópia que fica separada e protegida caso os dados principais sejam apagados ou atacados?",
								help: "Por exemplo, uma cópia que não possa ser alterada facilmente pelas mesmas pessoas ou sistemas usados no dia a dia.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.backupIsolation,
									onChange: (e) => set("backupIsolation", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "immutable",
											children: "Sim, existe uma cópia protegida contra alteração"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "isolated",
											children: "Sim, existe uma cópia separada ou offline"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "separate_account",
											children: "Sim, existe uma cópia administrada separadamente"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "same_environment",
											children: "Existe cópia, mas ela depende do mesmo ambiente ou das mesmas credenciais"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe uma cópia separada"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block" })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "A empresa já testou se consegue recuperar os dados a partir dessas cópias?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.restoreTests,
									onChange: (e) => set("restoreTests", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "regular",
											children: "Sim, periodicamente"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "once",
											children: "Já testamos alguma vez"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "never",
											children: "Nunca testamos"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Por quanto tempo a empresa consegue ficar sem os sistemas ou dados mais importantes?",
								help: "Pense no tempo máximo aceitável sem os sistemas ou dados mais importantes.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.maxDowntime,
									onChange: (e) => set("maxDowntime", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "4h",
											children: "Até 4 horas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "8h",
											children: "Até 8 horas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1d",
											children: "Até 1 dia"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "2d",
											children: "Até 2 dias"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "more",
											children: "Mais de 2 dias"
										})
									]
								})
							})] })
						]
					}),
					step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nas contas mais importantes, é exigida alguma confirmação além da senha?",
								help: "Por exemplo, um código no celular, aplicativo autenticador ou outra confirmação. Isso também é conhecido como MFA ou verificação em duas etapas.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.mfa,
									onChange: (e) => set("mfa", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "yes",
											children: "Sim, de forma ampla"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "partial",
											children: "Apenas em algumas contas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "no",
											children: "Não"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Mais de uma pessoa utiliza a mesma conta ou senha para acessar algum sistema?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.sharedAccounts,
									onChange: (e) => set("sharedAccounts", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "yes",
											children: "Sim"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "no",
											children: "Não"
										})
									]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Quando alguém sai da empresa, os acessos dessa pessoa são removidos?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.offboarding,
									onChange: (e) => set("offboarding", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "formal",
											children: "Sim, existe processo definido"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "informal",
											children: "É feito caso a caso"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "A empresa armazena ou utiliza dados pessoais ou informações sensíveis?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.sensitiveData,
									onChange: (e) => set("sensitiveData", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "yes",
											children: "Sim"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "no",
											children: "Não"
										})
									]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "O e-mail da empresa possui alguma proteção além do filtro padrão de spam?",
								help: "Por exemplo, bloqueio de mensagens falsas, links perigosos ou anexos suspeitos.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.emailProtection,
									onChange: (e) => set("emailProtection", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "advanced",
											children: "Sim, com análise de links, anexos e mensagens suspeitas"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "standard",
											children: "Sim, existe proteção adicional administrada pela empresa"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "basic",
											children: "Apenas o filtro padrão de spam do e-mail"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe proteção além do padrão"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Se acontecer um problema de segurança hoje, a empresa sabe quem deve coordenar a resposta?",
								help: "Pode ser alguém da empresa ou um prestador especializado. O importante é saber previamente quem deve ser acionado.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.incidentResponse,
									onChange: (e) => set("incidentResponse", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Não sei informar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "formal",
											children: "Sim, responsável e processo definidos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "informal",
											children: "Sabemos quem chamar, mas sem processo formal"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "none",
											children: "Não existe responsável definido"
										})
									]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuestionPair, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "A empresa já passou por vírus, invasão, perda de dados ou uma parada importante causada por tecnologia?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: select,
									value: a.incidentHistory,
									onChange: (e) => set("incidentHistory", e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "unknown",
											children: "Prefiro não informar / não sei"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "no",
											children: "Não"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "yes",
											children: "Sim"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Qual situação de segurança mais preocupa a empresa hoje?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: input,
									value: a.mainConcern,
									onChange: (e) => set("mainConcern", e.target.value),
									placeholder: "Ex.: vírus, golpe por e-mail, perda de dados, parada dos sistemas, LGPD..."
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Existe alguma informação importante que você gostaria de acrescentar?",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: input,
									rows: 4,
									value: a.notes,
									onChange: (e) => set("notes", e.target.value),
									placeholder: "Pode ser um sistema importante, mudança planejada, dificuldade atual ou qualquer outro contexto que ajude a entender o ambiente."
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex items-center justify-between border-t border-slate-800 pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex items-center gap-2 rounded-xl px-4 py-3 text-slate-300 transition hover:bg-slate-800/60 disabled:cursor-not-allowed disabled:opacity-30",
							disabled: step === 0 || isSubmitting,
							onClick: () => setStep((s) => s - 1),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 18 }), "Voltar"]
						}), step < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex items-center gap-2 rounded-xl bg-teal-600 px-5 py-3 font-semibold shadow-lg shadow-teal-950/30 transition hover:bg-teal-500 disabled:cursor-not-allowed disabled:opacity-60",
							disabled: isSubmitting,
							onClick: () => {
								setStep((s) => s + 1);
								window.scrollTo({
									top: 0,
									behavior: "smooth"
								});
							},
							children: ["Continuar", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 18 })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "flex min-w-[190px] items-center justify-center gap-2 rounded-xl bg-teal-600 px-5 py-3 font-semibold shadow-lg shadow-teal-950/30 transition hover:bg-teal-500 disabled:cursor-wait disabled:bg-teal-700 disabled:text-teal-100",
							onClick: submit,
							disabled: isSubmitting,
							"aria-busy": isSubmitting,
							children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								size: 18,
								className: "animate-spin"
							}), "Processando diagnóstico..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 18 }), "Enviar assessment"] })
						})]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex gap-2 text-sm text-slate-500",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						className: "mt-0.5 shrink-0",
						size: 17
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "As respostas compõem um diagnóstico inicial e serão revisadas pela equipe Concierge. O assessment não substitui validação técnica e não transforma “não sei informar” em falha automática." })]
				})
			]
		}), isSubmitting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 grid place-items-center bg-slate-950/72 px-4 backdrop-blur-[2px]",
			role: "status",
			"aria-live": "polite",
			"aria-label": "Preparando seu diagnóstico",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-sm rounded-2xl border border-teal-500/20 bg-slate-900/95 p-7 text-center shadow-2xl shadow-slate-950/60",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid h-12 w-12 place-items-center rounded-full border border-teal-500/20 bg-teal-500/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							className: "animate-spin text-teal-300",
							size: 24
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 text-lg font-bold text-white",
						children: "Preparando seu diagnóstico"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-slate-400",
						children: "Estamos organizando suas respostas e preparando a leitura de segurança."
					})
				]
			})
		})]
	});
}
var SplitComponent = AssessmentForm;
//#endregion
export { SplitComponent as component };
