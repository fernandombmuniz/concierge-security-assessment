import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-ziZv4XJG.mjs";
import { t as logo_concierge_default } from "./logo-concierge-CrmPVOHM.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as KeyRound, o as ShieldCheck, u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as createLovableAuth } from "../_libs/lovable.dev__cloud-auth-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-D5e8mGMC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var lovableAuth = createLovableAuth();
var lovable = { auth: { signInWithOAuth: async (provider, opts) => {
	const result = await lovableAuth.signInWithOAuth(provider, {
		...opts,
		extraParams: { ...opts?.extraParams }
	});
	if (result.redirected) return result;
	if (result.error) return result;
	try {
		await supabase.auth.setSession(result.tokens);
	} catch (e) {
		return { error: e instanceof Error ? e : new Error(String(e)) };
	}
	return result;
} } };
function AuthPage() {
	const nav = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("signin");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(({ data }) => {
			if (data.session) nav({ to: "/interno" });
		});
	}, [nav]);
	const submit = async (e) => {
		e.preventDefault();
		setBusy(true);
		setMsg(null);
		try {
			if (mode === "signin") {
				const { error } = await supabase.auth.signInWithPassword({
					email,
					password
				});
				if (error) throw error;
				nav({ to: "/interno" });
			} else {
				const { error } = await supabase.auth.signUp({
					email,
					password,
					options: { emailRedirectTo: `${window.location.origin}/interno` }
				});
				if (error) throw error;
				setMsg("Conta criada. Confirme o e-mail para acessar o painel interno.");
			}
		} catch (err) {
			setMsg(err instanceof Error ? err.message : "Não foi possível autenticar.");
		} finally {
			setBusy(false);
		}
	};
	const google = async () => {
		setMsg(null);
		const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
		if (result.error) {
			setMsg("Não foi possível entrar com o Google.");
			return;
		}
		if (result.redirected) return;
		nav({ to: "/interno" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-dashboard-animate bg-grid-tech px-4 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass-card w-full max-w-md p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: logo_concierge_default,
						alt: "Concierge Segurança Digital",
						className: "h-10 rounded-lg"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-bold uppercase tracking-[.2em] text-teal-400",
						children: "Uso interno Concierge"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-bold text-white",
						children: "Acesso do Account Manager"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mt-7 grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-slate-200",
								children: "E-mail corporativo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								required: true,
								value: email,
								onChange: (e) => setEmail(e.target.value),
								className: "rounded-xl border border-slate-700/70 bg-slate-950/60 px-4 py-3 text-slate-100 outline-none focus:border-teal-500/60",
								placeholder: "nome@concierge.seg.br"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-slate-200",
								children: "Senha"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								required: true,
								minLength: 8,
								value: password,
								onChange: (e) => setPassword(e.target.value),
								className: "rounded-xl border border-slate-700/70 bg-slate-950/60 px-4 py-3 text-slate-100 outline-none focus:border-teal-500/60",
								placeholder: "••••••••"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: busy,
							className: "mt-1 inline-flex items-center justify-center gap-2 rounded-xl bg-teal-600 px-5 py-3 font-bold text-white transition hover:bg-teal-500 disabled:opacity-50",
							children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "animate-spin",
								size: 18
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { size: 18 }), mode === "signin" ? "Entrar" : "Criar acesso"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: google,
					className: "mt-3 w-full rounded-xl border border-slate-700/70 bg-slate-950/40 px-5 py-3 font-semibold text-slate-200 transition hover:border-teal-500/40",
					children: "Entrar com Google"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setMode(mode === "signin" ? "signup" : "signin");
						setMsg(null);
					},
					className: "mt-4 text-sm text-teal-300 hover:text-teal-200",
					children: mode === "signin" ? "Primeiro acesso? Criar conta" : "Já tenho acesso"
				}),
				msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-amber-300",
					children: msg
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 flex items-start gap-2 text-xs text-slate-500",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
						size: 14,
						className: "mt-0.5 shrink-0 text-slate-600"
					}), "Apenas e-mails cadastrados como Account Manager visualizam os diagnósticos vinculados."]
				})
			]
		})
	});
}
//#endregion
export { AuthPage as component };
