import { a as stringType, i as objectType } from "../_libs/zod.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-BFFE07zL.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-UH_Jp6hR.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-Ci_UJ8g1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/internal.functions-BgTntIfz.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Área interna: leitura dos assessments gravados no banco.
*
* O vínculo entre o usuário autenticado e o registro de Account Manager é
* feito por e-mail no primeiro acesso, para que a RLS reconheça o AM.
*/
var listInternalAssessments = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("9ca52ce4aa10b3440afc94c3046896e5a7f57e15d698cb475e4f862a07a6ab74"));
var getInternalAssessment = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).inputValidator((input) => objectType({ id: stringType().uuid() }).parse(input)).handler(createSsrRpc("d41e6b99bc0389cbedfde2a2806fdb442b5c1613d9a71de862845630da2a7a90"));
//#endregion
export { listInternalAssessments as n, getInternalAssessment as t };
