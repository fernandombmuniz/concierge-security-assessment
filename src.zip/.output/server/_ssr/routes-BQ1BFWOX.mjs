import { i as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { c as MonitorSmartphone, d as KeyRound, h as Database, n as Wifi, o as ShieldCheck, u as LoaderCircle, w as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as useSearchParams, r as useNavigate$1 } from "./router-compat-D1jUaSai.mjs";
import { n as clearPreviousRespondentState, t as ClientHeader } from "./ClientHeader-DBh3ZhLU.mjs";
import { a as resetAttribution, c as startAssessment, i as readAttribution, s as saveSession, t as clearSession } from "./assessment-session-CXBePsz7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BQ1BFWOX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LandingPage() {
	const navigate = useNavigate$1();
	const [searchParams] = useSearchParams();
	const [consent, setConsent] = (0, import_react.useState)(false);
	const [starting, setStarting] = (0, import_react.useState)(false);
	const [entryReady, setEntryReady] = (0, import_react.useState)(false);
	const publicRef = searchParams.get("ref");
	const publicSource = searchParams.get("src");
	const isPublicEntry = Boolean(publicRef || publicSource);
	(0, import_react.useEffect)(() => {
		/**
		* Um link público com `ref` e/ou `src` representa uma NOVA entrada.
		* Antes de renderizar o cabeçalho ou permitir navegação, removemos todo o
		* estado local do respondente anterior. Assim um dispositivo compartilhado
		* não mostra rascunho, resultado ou sessão de outra pessoa.
		*
		* Ao navegar internamente de volta para `/` sem ref/src, não limpamos nada.
		* Isso preserva o assessment em andamento do próprio respondente.
		*/
		if (isPublicEntry) {
			clearPreviousRespondentState();
			clearSession();
			resetAttribution(publicRef, publicSource);
		}
		setEntryReady(true);
	}, [
		isPublicEntry,
		publicRef,
		publicSource
	]);
	const start = async () => {
		if (!consent || starting) return;
		setStarting(true);
		/**
		* Segunda proteção: mesmo que o usuário tenha chegado à landing por uma
		* navegação incomum, iniciar explicitamente um novo diagnóstico sempre
		* começa com estado local limpo.
		*/
		clearPreviousRespondentState();
		clearSession();
		if (isPublicEntry) resetAttribution(publicRef, publicSource);
		const { ref, source } = readAttribution();
		try {
			const [session] = await Promise.all([startAssessment({ data: {
				ref,
				source,
				consent: true
			} }), new Promise((resolve) => setTimeout(resolve, 450))]);
			saveSession({
				...session,
				ref,
				source,
				consentAt: (/* @__PURE__ */ new Date()).toISOString()
			});
			sessionStorage.setItem("concierge-assessment-route-transition", "1");
			navigate("/diagnostico", { replace: true });
		} catch (error) {
			console.error("Falha ao iniciar assessment:", error);
			alert("Não foi possível iniciar o diagnóstico neste momento. Verifique sua conexão e tente novamente.");
			setStarting(false);
		}
	};
	const features = [
		{
			title: "Rede e Perímetro",
			desc: "Análise de internet, firewalls e controle de acessos externos.",
			icon: Wifi,
			color: "text-cyan-400"
		},
		{
			title: "Dispositivos",
			desc: "Proteção de computadores, notebooks, servidores e atualizações.",
			icon: MonitorSmartphone,
			color: "text-teal-400"
		},
		{
			title: "Continuidade",
			desc: "Estratégias de backup, testes de restauração e tempo de parada.",
			icon: Database,
			color: "text-blue-400"
		},
		{
			title: "Identidade e Acesso",
			desc: "Controle de contas, múltiplos fatores (MFA) e offboarding.",
			icon: KeyRound,
			color: "text-indigo-400"
		}
	];
	/**
	* Durante a limpeza de uma nova entrada pública não renderizamos o header.
	* Isso evita até mesmo um flash visual com o nome/resultado do respondente
	* anterior antes do useEffect concluir.
	*/
	if (!entryReady) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { className: "min-h-screen bg-dashboard-animate bg-grid-tech" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-dashboard-animate bg-grid-tech px-4 py-7 md:py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card relative mt-6 overflow-hidden p-8 text-center md:p-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute right-0 top-0 -mr-20 -mt-20 h-64 w-64 rounded-full bg-teal-500/5 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute bottom-0 left-0 -mb-20 -ml-20 h-64 w-64 rounded-full bg-cyan-500/5 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 mx-auto max-w-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "section-kicker",
								children: "Assessment Executivo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 text-4xl font-extrabold leading-tight tracking-tight text-white md:text-5xl",
								children: "Concierge Security Assessment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-xl font-medium text-slate-200 md:text-2xl",
								children: "Uma avaliação inicial da postura de segurança da sua empresa."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-base leading-relaxed text-slate-400 md:text-lg",
								children: "A partir de algumas informações sobre rede, computadores, proteção de dados e acessos, identificamos pontos que merecem atenção e ajudamos a compreender como eles podem afetar a operação."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 rounded-xl border border-teal-500/20 bg-teal-500/5 px-5 py-3.5 text-sm font-medium text-slate-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
										className: "text-teal-400",
										size: 22
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Leva cerca de ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "6 a 8 minutos" })] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12 grid gap-6 text-left sm:grid-cols-2 md:grid-cols-4",
								children: features.map((feature) => {
									const Icon = feature.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl border border-slate-800 bg-slate-950/45 p-5 transition hover:border-slate-700/60",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `grid h-10 w-10 place-items-center rounded-lg border border-slate-800 bg-slate-900/50 ${feature.color}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 20 })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-4 font-bold text-slate-100",
												children: feature.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-xs leading-relaxed text-slate-400",
												children: feature.desc
											})
										]
									}, feature.title);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mx-auto mt-10 flex max-w-2xl cursor-pointer items-start gap-3 rounded-xl border border-slate-800 bg-slate-950/45 p-4 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: consent,
									onChange: (event) => setConsent(event.target.checked),
									className: "mt-0.5 h-4 w-4 shrink-0 accent-teal-500"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs leading-relaxed text-slate-400",
									children: "Autorizo a Concierge Segurança Digital a coletar e tratar as informações fornecidas neste diagnóstico com a finalidade de elaborar a avaliação de segurança e o contato comercial correspondente, conforme a Lei Geral de Proteção de Dados (LGPD). Os dados são utilizados apenas internamente e podem ser corrigidos ou excluídos a pedido."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: start,
									disabled: !consent || starting,
									"aria-busy": starting,
									className: "flex min-w-[220px] items-center justify-center gap-2 rounded-xl bg-teal-600 px-7 py-4 font-bold text-white shadow-lg shadow-teal-950/40 transition hover:scale-[1.02] hover:bg-teal-500 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-70 disabled:hover:scale-100",
									children: starting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
										className: "animate-spin",
										size: 20
									}), "Preparando diagnóstico..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Iniciar diagnóstico", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 20 })] })
								})
							})
						]
					})
				]
			})]
		}), starting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/72 px-4 backdrop-blur-sm",
			role: "status",
			"aria-live": "polite",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-sm rounded-2xl border border-teal-500/20 bg-slate-950/95 p-7 text-center shadow-2xl shadow-black/40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid h-12 w-12 place-items-center rounded-full border border-teal-500/20 bg-teal-500/10 text-teal-400",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							className: "animate-spin",
							size: 26
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-5 text-lg font-bold text-white",
						children: "Preparando seu diagnóstico"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-slate-400",
						children: "Estamos organizando as informações iniciais para começar sua avaliação. Isso leva apenas alguns instantes."
					})
				]
			})
		})]
	});
}
var SplitComponent = LandingPage;
//#endregion
export { SplitComponent as component };
