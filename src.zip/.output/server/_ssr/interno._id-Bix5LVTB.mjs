import { t as logo_concierge_default } from "./logo-concierge-CrmPVOHM.mjs";
import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { S as Building2, T as ArrowLeft, a as Target, c as MonitorSmartphone, d as KeyRound, f as Info, h as Database, n as Wifi, o as ShieldCheck, p as FileText, r as TriangleAlert, s as Server, x as ChartColumn } from "../_libs/lucide-react.mjs";
import { i as useParams$1, t as Link$1 } from "./router-compat-D1jUaSai.mjs";
import { r as scoreAssessment, t as emptyAssessment } from "./scoring-CLIBbsft.mjs";
import { t as getInternalAssessment } from "./internal.functions-BgTntIfz.mjs";
import { n as ImpactChart, r as ScoreGauge, t as DomainBars } from "./ImpactChart-DY4KBzpy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/interno._id-Bix5LVTB.js
var import_jsx_runtime = require_jsx_runtime();
function SeverityBadge({ severity }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-[.12em] ${severity === "Alta" ? "border-rose-500/30 bg-rose-500/10 text-rose-300" : severity === "Média" ? "border-amber-500/30 bg-amber-500/10 text-amber-300" : "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"}`,
		children: severity
	});
}
var money = (n) => new Intl.NumberFormat("pt-BR", {
	style: "currency",
	currency: "BRL",
	maximumFractionDigits: 0
}).format(n);
var usageLabel = {
	light: "Leve",
	medium: "Médio",
	high: "Intenso"
};
function InternalResults() {
	const { id } = useParams$1();
	const { data, isLoading } = useQuery({
		queryKey: ["internal-assessment", id],
		queryFn: () => getInternalAssessment({ data: { id } }),
		enabled: !!id
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-slate-950 p-8 text-slate-200",
		children: "Carregando assessment…"
	});
	if (!data?.found) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-slate-950 p-8 text-slate-200",
		children: "Assessment não encontrado."
	});
	const s = {
		id: data.assessment.id,
		createdAt: data.assessment.created_at,
		data: {
			...emptyAssessment,
			...JSON.parse(data.answersJson)
		}
	};
	const r = scoreAssessment(s.data);
	const domains = [
		{
			label: "Rede e Perímetro",
			value: r.scores.network,
			coverage: r.domainCoverage.network,
			confidence: r.domainConfidence.network,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, {
				size: 17,
				className: "text-cyan-400"
			})
		},
		{
			label: "Endpoints",
			value: r.scores.endpoint,
			coverage: r.domainCoverage.endpoint,
			confidence: r.domainConfidence.endpoint,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonitorSmartphone, {
				size: 17,
				className: "text-cyan-400"
			})
		},
		{
			label: "Backup e Continuidade",
			value: r.scores.backup,
			coverage: r.domainCoverage.backup,
			confidence: r.domainConfidence.backup,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, {
				size: 17,
				className: "text-cyan-400"
			})
		},
		{
			label: "Identidade e Acesso",
			value: r.scores.identity,
			coverage: r.domainCoverage.identity,
			confidence: r.domainConfidence.identity,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
				size: 17,
				className: "text-cyan-400"
			})
		}
	];
	const severityCount = {
		Alta: r.findings.filter((f) => f.severity === "Alta").length,
		Média: r.findings.filter((f) => f.severity === "Média").length,
		Baixa: r.findings.filter((f) => f.severity === "Baixa").length
	};
	const knownScore = r.overall !== null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-dashboard-animate bg-grid-tech px-4 py-8 md:py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$1, {
						to: "/interno",
						className: "inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 16 }), "Voltar aos assessments"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: logo_concierge_default,
							className: "h-9 rounded-md"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden text-right text-xs text-slate-500 sm:block",
							children: [
								"Concierge Security Assessment",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Prévia interna"
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "glass-card overflow-hidden p-6 md:p-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-8 lg:grid-cols-[1.3fr_.7fr] lg:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.22em] text-teal-400",
								children: "Security Assessment · Uso interno"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-3 text-4xl font-extrabold tracking-tight md:text-5xl",
								children: s.data.companyName || "Empresa não informada"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-3xl text-slate-400",
								children: "Leitura executiva e técnica baseada nas respostas fornecidas. O score representa maturidade relativa dos controles avaliados, não probabilidade absoluta de ataque."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex flex-wrap gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full border border-slate-700 bg-slate-950/40 px-3 py-1.5",
										children: s.data.sector || "Setor não informado"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-slate-700 bg-slate-950/40 px-3 py-1.5",
										children: [s.data.users || "—", " usuários"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-slate-700 bg-slate-950/40 px-3 py-1.5",
										children: [s.data.sites || 1, " unidade(s)"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full border border-slate-700 bg-slate-950/40 px-3 py-1.5",
										children: [
											"Dados respondidos: ",
											r.completeness,
											"%"
										]
									})
								]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreGauge, { value: r.overall })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-5 grid gap-5 lg:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold uppercase tracking-[.16em] text-slate-500",
										children: "Postura geral"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 text-3xl font-bold text-white",
										children: [r.overall ?? "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-base font-semibold text-slate-600",
											children: "/100"
										})]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "text-teal-400" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 text-sm text-slate-300",
									children: knownScore ? r.level : "Dados insuficientes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 h-2 overflow-hidden rounded-full bg-slate-800",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full bg-gradient-to-r from-cyan-500 to-teal-400",
										style: { width: `${r.overall ?? 0}%` }
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold uppercase tracking-[.16em] text-slate-500",
										children: "Prioridade identificada"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "text-amber-400" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 text-2xl font-bold text-white",
									children: r.priorityLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-slate-400",
									children: "Prioridade calculada pelo gap de controles combinado com contexto operacional, exposição e criticidade informada."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass-card p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold uppercase tracking-[.16em] text-slate-500",
										children: "Qualidade das respostas"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "text-cyan-400" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 text-3xl font-bold text-white",
									children: [r.completeness, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-slate-400",
									children: "Quanto maior a cobertura das respostas, mais contextualizado fica o diagnóstico."
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-5 grid gap-5 lg:grid-cols-[1.1fr_.9fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-6 md:p-7",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
								children: "Visão comparativa"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-2xl font-bold",
								children: "Maturidade por domínio"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "text-slate-600" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainBars, { items: domains })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-6 md:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
								children: "Distribuição dos achados"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-2xl font-bold",
								children: "Onde está a atenção"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-7 grid grid-cols-3 gap-3",
								children: [
									"Alta",
									"Média",
									"Baixa"
								].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/35 p-4 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `text-3xl font-extrabold ${k === "Alta" ? "text-rose-300" : k === "Média" ? "text-amber-300" : "text-emerald-300"}`,
										children: severityCount[k]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 text-xs uppercase tracking-wide text-slate-500",
										children: k
									})]
								}, k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 rounded-xl border border-slate-800 bg-slate-950/30 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-semibold text-slate-200",
									children: "Leitura recomendada"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-slate-400",
									children: "Comece pelos achados de severidade alta no domínio prioritário. O resultado orienta a conversa, mas não substitui validação técnica."
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-9",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
							children: "Diagnóstico contextual"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-2xl font-bold",
							children: "O que merece atenção"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm text-slate-500",
							children: [r.findings.length, " achado(s)"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-4 lg:grid-cols-2",
						children: r.findings.length ? r.findings.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "glass-card p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-sm font-semibold text-slate-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
											size: 17,
											className: "text-amber-300"
										}), f.domain]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeverityBadge, { severity: f.severity })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-xl font-bold leading-snug text-white",
									children: f.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 space-y-3 text-sm leading-relaxed",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-bold uppercase tracking-[.12em] text-slate-600",
											children: "O que identificamos"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-slate-300",
											children: f.situation
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-bold uppercase tracking-[.12em] text-slate-600",
											children: "Possível consequência"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-slate-300",
											children: f.consequence
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-lg border border-slate-800 bg-slate-950/35 p-3 text-slate-400",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
													className: "text-slate-300",
													children: "Ponto técnico avaliado:"
												}),
												" ",
												f.technical
											]
										})
									]
								})
							]
						}, `${f.domain}-${f.title}`)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "glass-card p-6 text-slate-400",
							children: "Nenhum achado prioritário foi gerado com os dados informados."
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-9 grid gap-5 lg:grid-cols-[.9fr_1.1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-6 md:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
								children: "Cenário operacional SMB"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-2xl font-bold",
								children: "Impacto ilustrativo de uma indisponibilidade"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 text-3xl font-extrabold text-white",
								children: [
									money(r.impactRange[0]),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base font-medium text-slate-500",
										children: "a"
									}),
									" ",
									money(r.impactRange[1])
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-slate-400",
								children: "Faixa de referência construída com o porte informado, tempo tolerável de parada e custos operacionais parametrizados para SMB. Não representa previsão de perda."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 rounded-xl border border-slate-800 bg-slate-950/35 p-4 text-sm text-slate-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "text-slate-200",
										children: "Pessoas consideradas:"
									}),
									" ",
									r.impactAssumptions.people
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-slate-200",
											children: "Horas de indisponibilidade:"
										}),
										" ",
										r.impactAssumptions.hours,
										"h"
									]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-6 md:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
								children: "Composição da faixa"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-2xl font-bold",
								children: "De onde vem a estimativa"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImpactChart, { components: r.impactComponents })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex gap-2 rounded-xl border border-cyan-900/40 bg-cyan-950/15 p-4 text-sm text-slate-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									size: 18,
									className: "mt-0.5 shrink-0 text-cyan-400"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Os parâmetros financeiros ficam centralizados na engine para revisão antes da publicação. O objetivo é manter valores compatíveis com a realidade de pequenas e médias empresas." })]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-9 grid gap-5 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-6 md:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
								children: "Opportunity Engine · uso interno"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-2xl font-bold",
								children: "Aderência comercial por frente"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-slate-500",
								children: "Este indicador não altera o score técnico. Ele ajuda o AM a escolher a próxima conversa."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 space-y-4",
								children: [
									[
										"Endpoint / EDR",
										r.opportunityFit.endpoint,
										r.opportunityNotes.endpoint
									],
									[
										"Backup",
										r.opportunityFit.backup,
										r.opportunityNotes.backup
									],
									[
										"Firewall",
										r.opportunityFit.firewall,
										r.opportunityNotes.firewall
									],
									[
										"Identidade",
										r.opportunityFit.identity,
										r.opportunityNotes.identity
									]
								].map(([label, value, note]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/30 p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-200",
												children: label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-teal-300",
												children: [value, "/100"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-2 h-1.5 overflow-hidden rounded-full bg-slate-800",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full bg-teal-500",
												style: { width: `${value}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-xs leading-relaxed text-slate-500",
											children: note
										})
									]
								}, label))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-6 md:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
								children: "Dependency Engine"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-2xl font-bold",
								children: "Sequência recomendada"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-slate-500",
								children: "Pré-requisitos identificados antes ou durante uma evolução de segurança."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 space-y-3",
								children: r.dependencies.length ? r.dependencies.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full border border-amber-800/50 bg-amber-950/20 px-2 py-0.5 text-2xs font-bold uppercase tracking-wide text-amber-300",
											children: d.status
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-slate-200",
											children: d.area
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-slate-400",
										children: d.message
									})]
								}, `${d.area}-${i}`)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "rounded-xl border border-slate-800 bg-slate-950/30 p-4 text-sm text-slate-400",
									children: "Nenhuma dependência relevante foi identificada com as respostas atuais."
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-9",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold uppercase tracking-[.16em] text-teal-400",
								children: "Uso interno"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-2xl font-bold",
								children: "Dados para pré-dimensionamento"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-slate-500",
								children: "Informações capturadas sem transformar o formulário do cliente em um checklist técnico extenso."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 md:grid-cols-2 xl:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass-card p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, {
										className: "text-cyan-400",
										size: 20
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 text-xs uppercase tracking-wide text-slate-600",
										children: "Capacidade"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 space-y-1 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Usuários ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.users || "—"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Endpoints ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.endpointCount || s.data.devices || "—"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Servidores ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.servers || 0
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Unidades ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.sites || 1
											})] })
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass-card p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, {
										className: "text-cyan-400",
										size: 20
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 text-xs uppercase tracking-wide text-slate-600",
										children: "Rede"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 space-y-1 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Links ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.internetLinkCount || 1
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Banda total ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
												className: "float-right text-white",
												children: [s.data.links[0]?.speedMbps || "—", " Mbps"]
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Uso ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: usageLabel[s.data.networkUsage]
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["VLANs ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.vlans || 0
											})] })
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass-card p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, {
										className: "text-cyan-400",
										size: 20
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 text-xs uppercase tracking-wide text-slate-600",
										children: "Acessos"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 space-y-1 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["VPN remota ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.vpnRemote || 0
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["VPN entre unidades ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right text-white",
												children: s.data.vpnSite || 0
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Firewall ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "float-right max-w-[140px] truncate text-white",
												children: s.data.firewallVendor || s.data.firewallLevel
											})] })
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass-card p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, {
										className: "text-cyan-400",
										size: 20
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 text-xs uppercase tracking-wide text-slate-600",
										children: "Continuidade"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 space-y-1 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Volume backup ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "float-right text-white",
											children: s.data.backupVolumeGb ? s.data.backupVolumeGb + " GB" : "—"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Parada tolerada ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "float-right text-white",
											children: s.data.maxDowntime === "unknown" ? "—" : s.data.maxDowntime
										})] })]
									})
								]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-9 grid gap-5 lg:grid-cols-[1fr_auto] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-2xl border border-teal-900/60 bg-teal-950/20 p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "mt-1 shrink-0 text-teal-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-bold text-white",
								children: "Metodologia desta versão"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm leading-relaxed text-slate-300",
								children: [
									"Os scores representam maturidade relativa dos controles informados. Respostas “não sei informar” reduzem a cobertura e entram com valor neutro, evitando que a ausência de informação gere uma nota artificialmente alta ou uma penalização automática. As faixas e pesos permanecem centralizados em ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "text-teal-300",
										children: "src/scoring.ts"
									}),
									" para validação antes do uso em produção."
								]
							})] })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$1, {
							to: "/diagnostico",
							className: "inline-flex items-center gap-2 rounded-xl border border-slate-700 px-4 py-3 text-sm font-semibold text-slate-300 hover:border-teal-500/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { size: 17 }), "Novo teste"]
						})
					})]
				})
			]
		})
	});
}
var SplitComponent = InternalResults;
//#endregion
export { SplitComponent as component };
