import { i as __toESM } from "../_runtime.mjs";
import { t as logo_concierge_default } from "./logo-concierge-CrmPVOHM.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as useLocation, t as Link$1 } from "./router-compat-D1jUaSai.mjs";
import { t as emptyAssessment } from "./scoring-CLIBbsft.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ClientHeader-DBh3ZhLU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEY = "concierge-client-assessments-v2";
var DRAFT = "concierge-client-assessment-draft-v2";
var LAST_ID = "concierge-client-last-assessment-id-v2";
var EDITING_ID = "concierge-client-editing-id-v2";
var STEP = "concierge-client-assessment-step-v2";
function saveSubmission(data) {
	const editingId = localStorage.getItem(EDITING_ID);
	const all = listSubmissions();
	if (editingId) {
		const existingIndex = all.findIndex((x) => x.id === editingId);
		if (existingIndex > -1) {
			all[existingIndex].data = data;
			all[existingIndex].createdAt = (/* @__PURE__ */ new Date()).toISOString();
			localStorage.setItem(KEY, JSON.stringify(all));
			localStorage.setItem(LAST_ID, editingId);
			localStorage.removeItem(EDITING_ID);
			return all[existingIndex];
		}
	}
	const item = {
		id: crypto.randomUUID(),
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		data
	};
	all.unshift(item);
	localStorage.setItem(KEY, JSON.stringify(all));
	localStorage.setItem(LAST_ID, item.id);
	localStorage.removeItem(EDITING_ID);
	return item;
}
function listSubmissions() {
	try {
		return JSON.parse(localStorage.getItem(KEY) || "[]");
	} catch {
		return [];
	}
}
function getSubmission(id) {
	return listSubmissions().find((x) => x.id === id);
}
function saveDraft(data) {
	localStorage.setItem(DRAFT, JSON.stringify(data));
}
function loadDraft() {
	try {
		return {
			...emptyAssessment,
			...JSON.parse(localStorage.getItem(DRAFT) || "{}")
		};
	} catch {
		return emptyAssessment;
	}
}
/**
* Remove todo o estado local que pertence ao respondente anterior.
*
* Use somente quando a aplicação identifica explicitamente o início de um
* NOVO assessment. A atribuição comercial (ref/src) e os dados enviados ao
* Supabase não são apagados por esta função.
*
* Isso evita que um navegador compartilhado exponha rascunhos ou resultados
* do último respondente ao abrir um novo link público.
*/
function clearPreviousRespondentState() {
	localStorage.removeItem(DRAFT);
	localStorage.removeItem(EDITING_ID);
	localStorage.removeItem(STEP);
	localStorage.removeItem(LAST_ID);
	localStorage.removeItem(KEY);
}
function ClientHeader() {
	const location = useLocation();
	const [hasAnswers, setHasAnswers] = (0, import_react.useState)(false);
	const [lastId, setLastId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const draft = loadDraft();
		const draftHasAnswers = !!(draft.companyName || draft.contactName || draft.contactEmail || draft.users && draft.users > 0 || draft.devices && draft.devices > 0 || draft.firewallLevel !== "unknown" || draft.endpointLevel !== "unknown" || draft.backupLevel !== "unknown" || draft.mfa !== "unknown");
		const persistedLastId = localStorage.getItem("concierge-client-last-assessment-id-v2");
		setLastId(persistedLastId);
		setHasAnswers(draftHasAnswers || !!persistedLastId);
	}, [location.pathname, location.search]);
	const navLinkClass = (path) => {
		return `
      flex min-h-11 items-center justify-center
      rounded-lg px-2 py-2
      text-center text-xs font-semibold
      transition
      sm:px-3.5 sm:text-sm
      ${location.pathname === path ? "bg-teal-500/10 text-teal-400" : "text-slate-400 hover:bg-slate-800/40 hover:text-slate-200"}
    `;
	};
	const handleEditClick = () => {
		const id = new URLSearchParams(location.search).get("id");
		if (id) {
			const sub = getSubmission(id);
			if (sub) {
				saveDraft(sub.data);
				localStorage.setItem("concierge-client-editing-id-v2", id);
				localStorage.setItem("concierge-client-assessment-step-v2", "0");
			}
			return;
		}
		const persistedLastId = localStorage.getItem("concierge-client-last-assessment-id-v2");
		if (persistedLastId) {
			const sub = getSubmission(persistedLastId);
			if (sub) {
				saveDraft(sub.data);
				localStorage.setItem("concierge-client-editing-id-v2", persistedLastId);
				localStorage.setItem("concierge-client-assessment-step-v2", "0");
			}
		}
	};
	const resultadoPath = lastId ? `/resultado?id=${lastId}` : "/resultado";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "\r\n        mb-7\r\n        rounded-2xl\r\n        border border-slate-800/80\r\n        bg-slate-950/35\r\n        p-4\r\n        backdrop-blur\r\n        sm:p-5\r\n        md:flex\r\n        md:items-center\r\n        md:justify-between\r\n        md:gap-6\r\n      ",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "\r\n          flex min-w-0\r\n          flex-col items-center\r\n          text-center\r\n          md:flex-row\r\n          md:items-center\r\n          md:text-left\r\n        ",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "\r\n            flex shrink-0\r\n            items-center justify-center\r\n          ",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: logo_concierge_default,
					alt: "Concierge Segurança Digital",
					className: "\r\n              h-auto\r\n              w-[190px]\r\n              max-w-full\r\n              rounded-lg\r\n              object-contain\r\n              sm:w-[220px]\r\n              md:w-auto\r\n              md:h-14\r\n            "
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "\r\n            mt-5\r\n            min-w-0\r\n            md:mt-0\r\n            md:ml-4\r\n          ",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "\r\n              text-[10px]\r\n              font-bold\r\n              uppercase\r\n              leading-relaxed\r\n              tracking-[0.2em]\r\n              text-teal-400\r\n              sm:text-xs\r\n              md:tracking-[0.22em]\r\n            ",
						children: "Concierge Segurança Digital"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "\r\n              mt-1\r\n              break-words\r\n              text-2xl\r\n              font-bold\r\n              leading-tight\r\n              text-white\r\n              md:text-2xl\r\n            ",
						children: "Security Assessment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "\r\n              mx-auto\r\n              mt-2\r\n              max-w-[290px]\r\n              text-xs\r\n              leading-relaxed\r\n              text-slate-400\r\n              sm:max-w-sm\r\n              md:mx-0\r\n              md:max-w-md\r\n            ",
						children: "Diagnóstico inicial de segurança para pequenas e médias empresas"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "\r\n          mt-6\r\n          w-full\r\n          md:mt-0\r\n          md:w-auto\r\n          md:shrink-0\r\n        ",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "\r\n            grid\r\n            w-full\r\n            grid-cols-3\r\n            gap-1\r\n            rounded-xl\r\n            border border-slate-800\r\n            bg-slate-950/50\r\n            p-1\r\n            md:flex\r\n            md:w-auto\r\n            md:flex-wrap\r\n            md:items-center\r\n          ",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						to: "/",
						className: navLinkClass("/"),
						children: "Início"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						to: "/diagnostico",
						className: navLinkClass("/diagnostico"),
						children: "Diagnóstico"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						to: resultadoPath,
						className: navLinkClass("/resultado"),
						children: "Resultado"
					}),
					hasAnswers && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						to: "/diagnostico",
						onClick: handleEditClick,
						className: "\r\n                col-span-3\r\n                mt-1\r\n                flex min-h-11\r\n                items-center\r\n                justify-center\r\n                rounded-lg\r\n                bg-amber-500/10\r\n                px-3 py-2\r\n                text-center\r\n                text-xs\r\n                font-semibold\r\n                text-amber-400\r\n                transition\r\n                hover:bg-amber-500/20\r\n                sm:text-sm\r\n                md:col-auto\r\n                md:mt-0\r\n              ",
						children: "Editar respostas"
					})
				]
			})
		})]
	});
}
//#endregion
export { saveDraft as a, loadDraft as i, clearPreviousRespondentState as n, saveSubmission as o, getSubmission as r, ClientHeader as t };
