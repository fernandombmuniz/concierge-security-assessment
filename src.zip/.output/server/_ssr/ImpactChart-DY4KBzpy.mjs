import { i as __toESM } from "../_runtime.mjs";
import { n as init_performance, r as performance_default } from "../_libs/canvg+[...].mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as maturityLevel } from "./scoring-CLIBbsft.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ImpactChart-DY4KBzpy.js
init_performance();
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var clamp = (value) => Math.min(100, Math.max(0, value));
var easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
function ScoreGauge({ value, label = "Postura geral", size = 170 }) {
	const gradientId = (0, import_react.useId)().replace(/:/g, "");
	const target = value === null ? 0 : clamp(value);
	const [displayValue, setDisplayValue] = (0, import_react.useState)(0);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [entered, setEntered] = (0, import_react.useState)(false);
	const [isAnimating, setIsAnimating] = (0, import_react.useState)(false);
	const radius = 62;
	const circumference = 2 * Math.PI * radius;
	const strokeOffset = circumference * (1 - progress / 100);
	(0, import_react.useEffect)(() => {
		let frame = 0;
		let startTimer = 0;
		if (value === null) {
			setDisplayValue(0);
			setProgress(0);
			setIsAnimating(false);
			return;
		}
		setDisplayValue(0);
		setProgress(0);
		setIsAnimating(true);
		startTimer = window.setTimeout(() => {
			const duration = 1400;
			const start = performance_default.now();
			const animate = (now) => {
				const elapsed = Math.min(1, (now - start) / duration);
				const eased = easeOutCubic(elapsed);
				const current = target * eased;
				setProgress(current);
				setDisplayValue(Math.round(current));
				if (elapsed < 1) frame = requestAnimationFrame(animate);
				else {
					setProgress(target);
					setDisplayValue(Math.round(target));
					setIsAnimating(false);
				}
			};
			frame = requestAnimationFrame(animate);
		}, 180);
		return () => {
			window.clearTimeout(startTimer);
			cancelAnimationFrame(frame);
		};
	}, [target, value]);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => setEntered(true), 70);
		return () => window.clearTimeout(timer);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "score-gauge transition-all duration-700 ease-out",
		style: {
			width: size,
			height: size,
			opacity: entered ? 1 : 0,
			transform: entered ? "scale(1)" : "scale(.94)"
		},
		"aria-label": `${label}: ${value === null ? "não avaliado" : `${value} de 100`}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 160",
			className: "absolute inset-0 h-full w-full -rotate-90",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "80",
					r: radius,
					fill: "none",
					stroke: "rgba(148,163,184,.14)",
					strokeWidth: "12"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "80",
					r: radius,
					fill: "none",
					stroke: `url(#${gradientId})`,
					strokeWidth: "12",
					strokeLinecap: "round",
					strokeDasharray: circumference,
					strokeDashoffset: strokeOffset,
					style: {
						filter: isAnimating ? "drop-shadow(0 0 10px rgba(20,184,166,.38))" : "drop-shadow(0 0 7px rgba(20,184,166,.18))",
						transition: "filter 300ms ease"
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: gradientId,
					x1: "0",
					y1: "0",
					x2: "1",
					y2: "1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0%",
						stopColor: "#22d3ee"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "100%",
						stopColor: "#14b8a6"
					})]
				}) })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 text-center transition-all duration-500",
			style: {
				opacity: entered ? 1 : 0,
				transform: entered ? "translateY(0)" : "translateY(4px)"
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-5xl font-extrabold tracking-tight text-white tabular-nums",
				children: value === null ? "—" : displayValue
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xs font-bold uppercase tracking-[.18em] text-slate-500",
				children: value === null ? "sem dados" : "de 100"
			})]
		})]
	});
}
function validationMessage(coverage) {
	if (typeof coverage !== "number") return null;
	if (coverage >= 80) return null;
	if (coverage >= 50) return "Alguns pontos precisam ser confirmados";
	return "Há pontos importantes a confirmar";
}
function DomainBars({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-5",
		children: items.map((item) => {
			const width = item.value ?? 0;
			const validation = validationMessage(item.coverage);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 font-semibold text-slate-200",
						children: [item.icon, item.label]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-lg font-bold text-white",
							children: item.value === null ? "—" : item.value
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 text-xs text-slate-500",
							children: "/100"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2.5 overflow-hidden rounded-full bg-slate-800",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-gradient-to-r from-cyan-500 to-teal-400 transition-all duration-700",
						style: { width: `${width}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1.5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: maturityLevel(item.value) }), validation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-slate-400",
						children: validation
					})]
				})
			] }, item.label);
		})
	});
}
var money = (n) => new Intl.NumberFormat("pt-BR", {
	style: "currency",
	currency: "BRL",
	maximumFractionDigits: 0
}).format(n);
function ImpactChart({ components }) {
	const rows = [
		["Produtividade parada", components.productivity],
		["Recuperação técnica", components.technical],
		["Impacto operacional", components.disruption]
	];
	const max = Math.max(...rows.map(([, v]) => v[1]), 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: rows.map(([label, range]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex justify-between gap-4 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-slate-300",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-semibold text-white",
				children: [
					money(range[0]),
					" – ",
					money(range[1])
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-2 overflow-hidden rounded-full bg-slate-800",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-gradient-to-r from-cyan-500/70 to-teal-400",
				style: { width: `${Math.max(8, range[1] / max * 100)}%` }
			})
		})] }, label))
	});
}
//#endregion
export { ImpactChart as n, ScoreGauge as r, DomainBars as t };
