import { t as supabase } from "./client-ziZv4XJG.mjs";
import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { C as ArrowUpRight, g as ClipboardList, l as LogOut, u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Link$1 } from "./router-compat-D1jUaSai.mjs";
import { n as listInternalAssessments } from "./internal.functions-BgTntIfz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/interno.index-qr_OZJK5.js
var import_jsx_runtime = require_jsx_runtime();
function InternalDashboard() {
	const { data, isLoading, error } = useQuery({
		queryKey: ["internal-assessments"],
		queryFn: () => listInternalAssessments()
	});
	const items = data?.items ?? [];
	const signOut = async () => {
		await supabase.auth.signOut();
		window.location.href = "/auth";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-dashboard-animate bg-grid-tech px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-bold uppercase tracking-[.2em] text-teal-400",
						children: "Uso interno Concierge"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-4xl font-bold",
						children: "Assessments recebidos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-slate-400",
						children: "Diagnósticos gravados no banco, vinculados ao Account Manager do link."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: signOut,
					className: "inline-flex items-center gap-2 rounded-xl border border-slate-700/70 bg-slate-950/40 px-4 py-2 text-sm font-semibold text-slate-300 hover:border-teal-500/40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 15 }), "Sair"]
				})]
			}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card flex items-center justify-center gap-3 p-10 text-slate-400",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					className: "animate-spin",
					size: 20
				}), "Carregando assessments…"]
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass-card p-8 text-center text-amber-300",
				children: "Não foi possível carregar os assessments."
			}) : !items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card p-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {
						className: "mx-auto text-slate-500",
						size: 42
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-xl font-bold",
						children: "Nenhum assessment enviado ainda"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-slate-400",
						children: [
							"Compartilhe seu link com ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "text-teal-300",
								children: "?ref="
							}),
							" para começar a receber diagnósticos."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$1, {
						to: "/diagnostico",
						className: "mt-5 inline-flex rounded-xl bg-teal-600 px-5 py-3 font-semibold hover:bg-teal-500",
						children: "Abrir assessment"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4",
				children: items.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$1, {
					to: `/interno/${s.id}`,
					className: "glass-card group grid gap-4 p-5 transition hover:border-teal-500/40 md:grid-cols-[1.4fr_.8fr_.8fr_auto] md:items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg font-bold text-white",
							children: s.company_name || "Empresa não informada"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm text-slate-500",
							children: [
								s.respondent_name || "Contato não informado",
								" · ",
								new Date(s.created_at).toLocaleString("pt-BR"),
								s.public_ref ? ` · ref: ${s.public_ref}` : "",
								s.source ? ` · ${s.source}` : ""
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-wide text-slate-500",
							children: "Postura geral"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-2xl font-bold text-teal-300",
							children: [s.overall_score ?? "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-slate-600",
								children: "/100"
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-wide text-slate-500",
							children: s.status === "completed" ? "Prioridade" : "Situação"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold text-slate-200",
							children: s.status === "completed" ? s.priority_domain_label || "—" : "Em andamento"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "text-slate-600 transition group-hover:text-teal-300" })
					]
				}, s.id))
			})]
		})
	});
}
var SplitComponent = InternalDashboard;
//#endregion
export { SplitComponent as component };
