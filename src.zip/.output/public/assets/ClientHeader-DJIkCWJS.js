import{n as e}from"./rolldown-runtime-CbXtAM7H.js";import{i as t,r as n}from"./useRouter-P4PaR9MS.js";import{n as r,t as i}from"./router-compat-QkrA-YOn.js";import{a}from"./monitor-smartphone-B1zNNjhj.js";import{n as o}from"./key-round-lJWnzHCV.js";var s=e(t(),1),c=`concierge-client-assessments-v2`,l=`concierge-client-assessment-draft-v2`,u=`concierge-client-last-assessment-id-v2`,d=`concierge-client-editing-id-v2`,f=`concierge-client-assessment-step-v2`;function p(e){let t=localStorage.getItem(d),n=m();if(t){let r=n.findIndex(e=>e.id===t);if(r>-1)return n[r].data=e,n[r].createdAt=new Date().toISOString(),localStorage.setItem(c,JSON.stringify(n)),localStorage.setItem(u,t),localStorage.removeItem(d),n[r]}let r={id:crypto.randomUUID(),createdAt:new Date().toISOString(),data:e};return n.unshift(r),localStorage.setItem(c,JSON.stringify(n)),localStorage.setItem(u,r.id),localStorage.removeItem(d),r}function m(){try{return JSON.parse(localStorage.getItem(c)||`[]`)}catch{return[]}}function h(e){return m().find(t=>t.id===e)}function g(e){localStorage.setItem(l,JSON.stringify(e))}function _(){try{return{...a,...JSON.parse(localStorage.getItem(l)||`{}`)}}catch{return a}}function v(){localStorage.removeItem(l),localStorage.removeItem(d),localStorage.removeItem(f),localStorage.removeItem(u),localStorage.removeItem(c)}var y=n();function b(){let e=r(),[t,n]=(0,s.useState)(!1),[a,c]=(0,s.useState)(null);(0,s.useEffect)(()=>{let e=_(),t=!!(e.companyName||e.contactName||e.contactEmail||e.users&&e.users>0||e.devices&&e.devices>0||e.firewallLevel!==`unknown`||e.endpointLevel!==`unknown`||e.backupLevel!==`unknown`||e.mfa!==`unknown`),r=localStorage.getItem(`concierge-client-last-assessment-id-v2`);c(r),n(t||!!r)},[e.pathname,e.search]);let l=t=>`
      flex min-h-11 items-center justify-center
      rounded-lg px-2 py-2
      text-center text-xs font-semibold
      transition
      sm:px-3.5 sm:text-sm
      ${e.pathname===t?`bg-teal-500/10 text-teal-400`:`text-slate-400 hover:bg-slate-800/40 hover:text-slate-200`}
    `,u=()=>{let t=new URLSearchParams(e.search).get(`id`);if(t){let e=h(t);e&&(g(e.data),localStorage.setItem(`concierge-client-editing-id-v2`,t),localStorage.setItem(`concierge-client-assessment-step-v2`,`0`));return}let n=localStorage.getItem(`concierge-client-last-assessment-id-v2`);if(n){let e=h(n);e&&(g(e.data),localStorage.setItem(`concierge-client-editing-id-v2`,n),localStorage.setItem(`concierge-client-assessment-step-v2`,`0`))}},d=a?`/resultado?id=${a}`:`/resultado`;return(0,y.jsxs)(`header`,{className:`\r
        mb-7\r
        rounded-2xl\r
        border border-slate-800/80\r
        bg-slate-950/35\r
        p-4\r
        backdrop-blur\r
        sm:p-5\r
        md:flex\r
        md:items-center\r
        md:justify-between\r
        md:gap-6\r
      `,children:[(0,y.jsxs)(`div`,{className:`\r
          flex min-w-0\r
          flex-col items-center\r
          text-center\r
          md:flex-row\r
          md:items-center\r
          md:text-left\r
        `,children:[(0,y.jsx)(`div`,{className:`\r
            flex shrink-0\r
            items-center justify-center\r
          `,children:(0,y.jsx)(`img`,{src:o,alt:`Concierge Segurança Digital`,className:`\r
              h-auto\r
              w-[190px]\r
              max-w-full\r
              rounded-lg\r
              object-contain\r
              sm:w-[220px]\r
              md:w-auto\r
              md:h-14\r
            `})}),(0,y.jsxs)(`div`,{className:`\r
            mt-5\r
            min-w-0\r
            md:mt-0\r
            md:ml-4\r
          `,children:[(0,y.jsx)(`div`,{className:`\r
              text-[10px]\r
              font-bold\r
              uppercase\r
              leading-relaxed\r
              tracking-[0.2em]\r
              text-teal-400\r
              sm:text-xs\r
              md:tracking-[0.22em]\r
            `,children:`Concierge Segurança Digital`}),(0,y.jsx)(`h1`,{className:`\r
              mt-1\r
              break-words\r
              text-2xl\r
              font-bold\r
              leading-tight\r
              text-white\r
              md:text-2xl\r
            `,children:`Security Assessment`}),(0,y.jsx)(`p`,{className:`\r
              mx-auto\r
              mt-2\r
              max-w-[290px]\r
              text-xs\r
              leading-relaxed\r
              text-slate-400\r
              sm:max-w-sm\r
              md:mx-0\r
              md:max-w-md\r
            `,children:`Diagnóstico inicial de segurança para pequenas e médias empresas`})]})]}),(0,y.jsx)(`div`,{className:`\r
          mt-6\r
          w-full\r
          md:mt-0\r
          md:w-auto\r
          md:shrink-0\r
        `,children:(0,y.jsxs)(`nav`,{className:`\r
            grid\r
            w-full\r
            grid-cols-3\r
            gap-1\r
            rounded-xl\r
            border border-slate-800\r
            bg-slate-950/50\r
            p-1\r
            md:flex\r
            md:w-auto\r
            md:flex-wrap\r
            md:items-center\r
          `,children:[(0,y.jsx)(i,{to:`/`,className:l(`/`),children:`Início`}),(0,y.jsx)(i,{to:`/diagnostico`,className:l(`/diagnostico`),children:`Diagnóstico`}),(0,y.jsx)(i,{to:d,className:l(`/resultado`),children:`Resultado`}),t&&(0,y.jsx)(i,{to:`/diagnostico`,onClick:u,className:`\r
                col-span-3\r
                mt-1\r
                flex min-h-11\r
                items-center\r
                justify-center\r
                rounded-lg\r
                bg-amber-500/10\r
                px-3 py-2\r
                text-center\r
                text-xs\r
                font-semibold\r
                text-amber-400\r
                transition\r
                hover:bg-amber-500/20\r
                sm:text-sm\r
                md:col-auto\r
                md:mt-0\r
              `,children:`Editar respostas`})]})})]})}export{g as a,_ as i,v as n,p as o,h as r,b as t};